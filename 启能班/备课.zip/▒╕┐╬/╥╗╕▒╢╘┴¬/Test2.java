public class Test2{

	static void test(){
		try{
			String x = null;
			System.out.println(x.toString()+"	");
		}finally{
			System.out.println("Love");
		}
	}
	public static void main(String[] args){
		test();// what is the result?
	}
}