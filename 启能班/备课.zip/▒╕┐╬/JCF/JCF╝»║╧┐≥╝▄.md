# JCF集合框架



```
JCF  = Java Collections Framework  => Java集合框架
Java中的框架 是一套体系结构 非Spring框架性质
W: 是什么？
W：为什么要用？

什么是集合？
集合指的是存放数据的容器，与数组相同 但相对集合 数组有很多的局限或不足之处

首先 数组有什么不好的地方
	大家都见过蛋托 (商场里用来存放鸡蛋的)  每个格子是等大的 可以连续的存放多个鸡蛋 在编程中相当于数组，	 而存放鸡蛋的蛋托 放鹅蛋就放不下去，如果放鹌鹑蛋 就太大 容易破碎 也就是说 当数组定义为一个类型的     	时候它是不允许存放其它类型的数据 另外 假如一个蛋托有连续等大的六块空间 我想存放20个鸡蛋 怎么办，首先	 我需要先去存储空间创建一个可以存放20个鸡蛋的存储空间 然后在把这六个鸡蛋的内存指向可以存放20个鸡蛋的	 存储空间中 这样做 我们会非常累，因为我要先去创建新数组 然后复制元素 改变引用指向 在期盼GC赶快把之	 前的老数组抓紧回收掉
	
例如 天气热了 请小伙伴帮我去买雪糕，通常情况下我吃一个肯定不够，于是我作为他的上级 调用小伙伴帮我买雪糕的	  方法 提供RMB 指定雪糕的数量 然后小伙伴去买了N个雪糕回来，那么作为小伙伴的你是怎么把这N个雪糕返回给     我的,肯定不是肯定不是拿手捧着回来的，肯定是直接放到胶袋中统一返回给我，而这个胶袋在Java中指的就是集     合

限塑令：限制使用胶袋，即便是限制使用 那商场中参加与购物的阿公阿婆还是中意花钱去买 因为使用确实太方便了
我们将蛋托理解成数组的话 那么胶袋就是集合

集合就是存放数据的容器 相比数组更加功能强大

Java中的集合分为两大分支    Collection      Map
Collection  存放单支对象
Map 存放键值对
	键值对  ： 现实生活中 有些是单个出现的 例如帽子，衣服 ，有些则是成对出现的 例如手套，鞋子等
			在例如 写一个拼写检查工具 
			key=value
			apple=香蕉    
			banana=橘子 
			orange=苹果

```

## Collection分支

```
			Collection 单值类型集合
	List								Set
	[要求元素有序]						[元素无需]
	[要求元素不唯一]						["唯一"]
	
	
										SortedSet
										[有序且"唯一"]
										
	
```

## List

### ArrayList

#### 包装类

```java
import java.util.*;

// 包装类  Wrapper Class  JDK5.0新特性  ：自带打包 自带解包
public class TestArrayList0{
	public static void main(String[] args){
		// Java当中数据类型有两种 基本数据类型  引用类型
		// Java当中的集合只允许存放引用类型的对象 换言之 只能放对象
		ArrayList<Integer> list = new ArrayList<>();
		// JDK5.0之前 下边这句话会报错 就是说5.0之前不允许将基本数据类型直接存放到集合当中
		list.add(3);// 5.0之前 list.add(new Integer(3));
		list.add(5);
		// 从JDK5.0开始  基本数据类型和它对应的包装类类型可以直接赋值 - 自动打包
		int num1 = 3;
		Integer num2 = num1;// Integer num2 = new Integer(num1);
		// 从JDK5.0开始 包装类类型和它对应的基本数据类型也可以直接赋值  自动解包
		Integer num3 = 7;
		int num4 = num3;// int num4 = num3.intValue();
		// SCJP
		Boolean data1 = null;// 引用类型默认值null
		boolean data2 = data1;// data1.booleanValue();
		System.out.println(data2);//?   true / false
	}
}

/*
	首先我们要知道 Java中给我们提供了8中基本数据类型
	boolean char 	  byte short int 	 long float double
	Boolean Characset Byte Short Integer Long Float Double
*/

// 既然不能直接存放基本数据类型 我们可以将基本数据类型包装起来 然后把引用类型放到集合中
class A{ // 引用类型
	private int value; // 基本数据类型
	public A(int value){
		// 构造方法赋值
	}

	public int intValue(){
		return value;
	}

}
```

### ArrayList基本用法

```java
import java.util.*;
// ArrayList最基本的用法
/*
	创建ArrayList对象	new ArrayList<>([数组初始化元素个数 不写默认10块空间]);
	添加元素 			add();
	得到第几个元素		get(int index);
	获取集合元素个数	size();
	遍历集合
		1	for + get(index)
		2 	foreach
		3 	Iterator
	清空集合	clear();
	删除集合中的某个元素 remove();
*/
public class TestArrayList1{
	public static void main(String[] args){
		// 创建ArrayList对象
		ArrayList list = new ArrayList();// 胶袋 & 卡车 可以存放任意类型的数据
		// 如果我们想要这个集合中只能够存放某种类型的数据 使用泛型  JDK5.0新特性
		ArrayList<Integer> list2 = new ArrayList<>();// 默认10块空间
		// 多态方式创建ArrayList
		//List<Integer> list2 = new ArrayList<>();
		// 向集合中添加元素
		list2.add(5);
		list2.add(3);
		list2.add(5);
		// 获取集合中元素大小
		System.out.println(list2.size());
		// 获取集合中的元素
		System.out.println(list2);// 直接打印内容 则表示ArrayList中已经覆盖了toString方法

		// 获取指定位置的元素
		System.out.println(list2.get(0));// data[0]
		// 获取集合中全部元素 - 遍历集合
		// 1 for+循环变量
		for(int i=0;i<list2.size();i++){
			System.out.println(list2.get(i));
		}
		System.out.println("============");
		// 2 foreach  5.0
		for(Integer i:list2){
			System.out.println(i);
		}
		System.out.println("============");
		// 3 Iterator 迭代器
		/*
			迭代器 简单理解 装卸货物的小推车 有三个重要方法
			测试还有没有下一件获取   hasNext();
			得到车上的下一件获取  next();
			移除当前获取 remove();
		*/
		Iterator<Integer> car = list2.iterator();
		while(car.hasNext()){// 测试还有没有下一件货物
			System.out.println(car.next());// 得到下一件货物
		}
		// 清空集合
		list2.clear();
		System.out.println(list2.size());
	}
}
```

### ArrayList效率问题

```
1. 构造方法传参
2. trimToSize 调整集合底层实际存储大小
3. ensureCapcity 添加一些元素之后在动态调整底层数组大小
4. 模拟ArrayList 简单的CURD
```

#### 构造方法传参

```java
// 6.0 (oldCapcity*3/2)+1
// 7. oldCapcity + (oldCapcity>>1)
// 默认10块空间
/*
	JDK 7.0开始的扩容机制
	当添加第11个元素的时候 扩容到15
				10 + (10>>1) = 15
	当添加第16个元素的时候  15 + （15>>1） = 22
    当添加第23个元素的时候 22 + (22>>1) = 33
*/
import java.util.*;
import java.lang.refect.*;
public class TestConstroct{
    
    public static void main(String[] args)throws Exception{
         ArrayList<Object> list = new ArrayList<>(10); 
       	Object o = new Object();
       	for(int i=0;i<11;i++){// 11 -> 15  16 -> 22 23 -> 33
          list.add(o); 
       	}
        // 验证添加元素后底层数组大小
        Class<?> c  = Class.forName("java.util.ArrayList");
        Fields f = c.declaredField("elementData");
        f.setAccessbale(true);
        System.out.println(f.length);// 11 -> 15  16 -> 22 23 -> 33
    }
  
}
```

##### 效率问题 - trimToSize

```java
/*
	关于效率问题
		trimToSize 当我们添加完成元素后 底层的空间大小肯定要比我们实际添加的元素大
			但为了保证不占用存储空间(添加的元素是在内存中的) 
			使用trimToSize调整底层数组大小与我们添加的元素个数保持一致
		
*/
import java.util.*;
public class Test{
   public static void main(String[] args){
       ArrayList<Integer> list = new ArrayList<>(2);
       list.add(1);
       list.add(2);
       list.add(3);// 触发扩容
       
       list.trimToSize();// 调整底层数组大小
       
        // 验证添加元素后底层数组大小
        Class<?> c  = Class.forName("java.util.ArrayList");
        Fields f = c.declaredField("elementData");
        f.setAccessbale(true);
        System.out.println(f.length);// 3
   } 
   
}
```

##### 效率问题 - ensureCapcity

```java
```



### LinedList

采用散列表存储

```
import java.util.*;
public class TestLinkedList{
	public static void main(String[] args){
		LinkedList<Integer> list = new LinkedList<>();
		list.add(33);
		list.add(55);
		list.add(33);
		System.out.println(list.size());
		//
		System.out.println(list.get(0));

		Iterator<Integer> car = list.iterator();
		while(car.hasNext()){
			System.out.println(car.next());
		}
	}
}
```

### Stack

采用栈格式存储

```
//LIFO = Last In First Out (后进先出) 栈结构
//push() 向栈顶压入一个新元素  pop() 从栈顶取走一个元素
import java.util.*;
public class TestStack{
	public static void main(String[] args){
		Stack<Integer> stack = new Stack<Integer>();
		stack.push(1);
		stack.push(2);
		stack.push(3);
		stack.push(4);
		stack.push(5);
		System.out.println(stack.pop());
		System.out.println(stack.pop());
	}
}
```

### Vector

采用数组 线程安全

```
import java.util.*;
public class TestVector{
	public static void main(String[] args){
		Vector<Integer> list = new Vector<Integer>(23);//集合
		list.add(5);//list.add(new Integer(5));
		list.add(3);
		list.add(2);
		list.add(1);
		list.add(1);
		list.add(4);
		System.out.println(list.size());
		System.out.println(list);
		System.out.println(list.get(0));
		//如何遍历集合
		for(int i = 0 ;i<list.size();i++){
			System.out.println(list.get(i));
		}
		/*
			boolean char byte short int long float double
			Boolean Character Byte Short Integer Long Float Double
		*/
	}
}
```

## Set

```
要求元素无序 而且唯一（重样的不能出现两个）
HashSet = 底层采用哈希表(散列表)实现
1.HashSet的基本用法 如何添加元素 如何得到元素个数 
	如何遍历 迭代器 Iterator (小推车)
		hasNext() 判断有没有下一件货物
		next()	  得到下一件货物
		remove()  删除当前所指的货物
		
2. 使用HashSet注意事项
ConcurrentModificationException = 并发修改异常
任何集合千万不要在使用迭代器遍历的过程中 对集合有任何整体的操作 包括添加 删除

```

### HashSet基本用法

```java
import java.util.*;
//HashSet（无序 唯一）的基本用法
public class TestHashSet1{
	public static void main(String[] args){
		HashSet<Integer> hs = new HashSet<Integer>();
		hs.add(5);//添加元素
		hs.add(3);
		hs.add(4);
		hs.add(1);
		hs.add(2);
		//如何遍历
		//Iterator(迭代器)
		Iterator<Integer> car = hs.iterator();
		while(car.hasNext()){
			Integer data = car.next();
			System.out.println(data);
		}

		//foreach
		for(Integer i:hs){
			System.out.println(i);
		}

		System.out.println(hs.size());//得到元素个数
		System.out.println(hs);
	}
}

```

### HashSet使用注意事项

```
任何集合千万不要在使用迭代器遍历的过程中 对集合有任何整体的操作 包括添加 删除
谁动了我的奶酪！！！
ConcurrentModificationException = 并发修改异常

删除没有的元素和添加已存在的元素时不会报异常，但删除已有的元素或添加不存在的元素时会报并发修改异常
```

```java
import java.util.*;
public class TestHashSet8{
	public static void main(String[] args){
		HashSet<Integer> hs = new HashSet<Integer>();
		hs.add(77);
		hs.add(98);
		hs.add(26);//new Integer(26)
		hs.add(35);
		hs.add(38);
		hs.add(46);
		//要求删除26
		//hs.remove(26);
		Iterator<Integer> car = hs.iterator();
		while(car.hasNext()){
			Integer data = car.next();
			if(data<60){
				car.remove();
				//hs.remove(99);
				//hs.add(98);
			}
		}
	}
}
```

### List

```java
import java.util.*;
public class TestArrayList{
	public static void main(String[] args){
		List<Integer> list = new ArrayList<>();
		list.add(33);
		list.add(55);
		list.add(77);
		list.add(99);
		Iterator<Integer> car = list.iterator();
		while(car.hasNext()){
			if(car.next()==77){
				list.add(55);// 并发修改异常
			}
		}
		System.out.println(list);
	}
}
```

### Set集合判定唯一三部曲

```
HashSet所谓的唯一 是通过hashCode和equals两个方法来判定的
其实判定唯一的过程并非两个步骤 而是三个步骤
hashCode()	==	equals()
	hashCode() && (== || equals())
HashSet删除元素同样尊重三步比较机制 过程相同 但是结论相反
	添加的时候 找到"相同"的对象 那么不再继续添加
	删除的时候 找到"相同"的对象 那么才进行删除操作	
	
HashSet添加元素的时候 如果遭遇了重复元素 那么新来的直接舍弃
	先入为主 先到先得	*绝对没有替换的机制
```

```java
import java.util.*;
public class TestHashSet2{
	public static void main(String[] args){
		// HashSet是个唯一集合 那它怎么确保唯一的呢？
		//其实HashSet所谓的唯一是"唯一"
		// 实是通过hashCode和equals的判定结论来判断唯一与否
		HashSet<Integer> set = new HashSet<>();
		set.add(33);
		set.add(55);
		set.add(33);
		System.out.println(set);

		HashSet<Student> set2 = new HashSet<>();
		set2.add(new Student("Tom",12));
		set2.add(new Student("Tom",12));
		set2.add(new Student("Tom",12));
		System.out.println(set2);
	}
}

class Student{
	String name;
	int age;
	public Student(String name,int age){
		this.name = name;
		this.age = age;
	}

	@Override
	public boolean equals(Object obj){
		if(obj == null) return false;
		if(!(obj instanceof Student)) return false;
		if(obj == this) return true;
		Student s1 = this;
		Student s2 = (Student)obj;
		return s1.name.equals(s2.name) && s1.age == s2.age;
	}
	@Override
	public int hashCode(){
		return name.hashCode()+age;
	}

	@Override
	public String toString(){
		return name+"-"+age;
	}
}
```

HashSet中元素的唯一是先到先得还是后来为主？

```java
import java.util.*;
public class TestHashSet3{
	public static void main(String[] args){
		// HashSet中的元素既然是唯一的 那么是先到先得还是后来的元素替换已有的元素？
		HashSet<Student2> set = new HashSet<>();
		set.add(new Student2("Tom"));
		set.add(new Student2("Jerry"));

		System.out.println(set);
	}
}

class Student2{
	String name;
	public Student2(String name){
		this.name = name;
	}

	@Override
	public boolean equals(Object o){
		return true;
	}
	@Override
	public int hashCode(){
		return 1;
	}

	public String toString(){
		return name;
	}
}
```

### 作业

```
需求：分配宿舍
	学生对象有属性 名字，年龄，性别
	要求只要性别相同就认定为同一对象
```

```java
import java.util.*;
public class TestHomeWork{
	public static void main(String[] args){
		HashSet<Student3> set = new HashSet<>();
		set.add(new Student3("Tom",12,"男"));
		set.add(new Student3("Judy",13,"女"));
		set.add(new Student3("Andy",15,"男"));

		System.out.println(set);
	}
}

class Student3{
	String name;
	int age;
	String gender;
	public Student3(String name,int age,String gender){
		this.name = name;
		this.age = age;
		this.gender = gender;
	}

	@Override
	public boolean equals(Object o){
		if(!(o instanceof Student3)) return false;
		if(o==null) return false;
		if(o==this) return true;
		Student3 s1 = this;
		Student3 s2 = (Student3)o;
		return s1.gender.equals(s2.gender);
	}

	public int hashCode(){
		return gender.hashCode();
	}

	public String toString(){
		return name+"-"+age+"-"+gender;
	}
}
```

### 集合排序



```java
import java.util.*;
public class TestA{
	public static void main(String[] agrs){
		List<Stu> list = new ArrayList<>();
		Collections.addAll(list,new Stu("张三",12,100),new Stu("李四",12,100),new Stu("王五",13,101));
		//Collections.sort(list);
		Collections.reverse(list);

		System.out.println(list);

	}
}

class Stu implements Comparable<Stu>{
	String name;
	int age;
	int score;
	public Stu(String name,int age,int score){
		this.name = name;
		this.age = age;
		this.score = score;
	}
	public int compareTo(Stu o){
		if(this.age==o.age){
			return this.score-o.score;
		}else{
			return this.age - o.age;
		}
	}

	public String toString(){
		return "student=["+name+","+age+","+","+score+"]";
	}
}
```



### TreeSet

```
TreeSet底层数据结构采用红黑树（平衡二叉树）来实现
元素唯一且已经排好序；唯一同样需要重写hashCode和equals()方法
二叉树结构保证了元素的有序 根据构造方法不同，分为自然排序（无参构造）和比较器排序（有参构造）

要想往TreeSet中添加元素
要添加的元素的类型，必须实现Comparable接口
重写当中compareTo方法
返回一个int
负数	往左子树走
0	舍弃
正数	往右子树走
```

基本使用

注意 同样在使用迭代器遍历时禁止修改或删除或添加元素

如果必须要修改 1删除 2 修改 3添加

```java
import java.util.*;
public class TestTreeSet{
	public static void main(String[] args){
		HashSet<Student4> set = new HashSet<>();
		set.add(new Student4("A",12));
		set.add(new Student4("B",15));

		System.out.println(set);

		for(Student4 s:set)
			System.out.println(s);


		Iterator<Student4> car = set.iterator();
		while(car.hasNext()){
			System.out.println(car.next());
			//set.add(new Student4("B",15));
		}
	}
}

class Student4 {
	String name;
	Integer age;
	public Student4(String name,int age){
		this.name = name;
		this.age = age;
	}

	public String toString(){
		return name+","+age;
	}

}
```



```java
import java.util.*;
public class TestTreeSet3{
	public static void main(String[] args){
		//如果需求决定必须要去修改 那么需要1删 2改 3添加
		TreeSet<A> ts = new TreeSet<A>();
		A a1 = new A(7);
		A a2 = new A(5);
		ts.add(a1);
		ts.add(a2);
		ts.remove(a2);
		a2.i = 9;
		ts.add(a2);
		System.out.println(ts);
	}
}

class A implements Comparable<A>{
	int i;
	public A(int i){
		this.i = i;
	}
	@Override
	public int compareTo(A a){
		A a1 = this;
		A a2 = a;
		return a1.i - a2.i;
	}
	@Override
	public String toString(){
		return "A:"+i;
	}
}
```

#### 比较器

##### Comparable接口

Comparable接口是自然排序接口，实现此接口的类就拥有了比较大小的能力，该接口只有一个方法 int comparareTo(T)

返回值说明

正数  当前对象比T大

负数 当前对象比T小

0 当前对象等于T

需求 按照升序方式对学生成绩进行排序

```java
import java.util.*;
public class TestComparable{
	public static void main(String[] args){
		TreeSet<Student5> ts = new TreeSet<Student5>();
		Student5 s1 = new Student5("a",97);
		Student5 s2 = new Student5("b",65);
		Student5 s3 = new Student5("c",80);
		Student5 s4 = new Student5("d",70);
		ts.add(s1);
		ts.add(s2);
		ts.add(s3);
		ts.add(s4);
		System.out.println(ts);
	}
}

class Student5 implements Comparable<Student5>{
	String name;
	int score;
	public Student5(String name,int score){
		this.name = name;
		this.score = score;
	}
	public int compareTo(Student5 s){
		return this.score - s.score;
	}
	public String toString(){
		return name + " " + score ;
	}
}
```

##### Compartor接口

该接口为函数式接口，可自定义比较规则

Comparable	compareTo(x);	写在定义的类体
Comparator	compare(x1,x2);	创建比较器实现的，将其对象作为参数添加进集合

```java
import java.util.*;
public class TestTreeSet4{
	public static void main(String[] args){
	/**
		Comparable 和 Comparator 同时实现时，则以Comparator为主
		
	*/
		StudentHigh sh = new StudentHigh();
		TreeSet<Student> ts = new TreeSet<Student>(sh);
		Student s1 = new Student("asd",97,165);
		Student s2 = new Student("zxc",65,190);
		Student s3 = new Student("qwe",80,180);
		Student s4 = new Student("qaz",70,170);
		ts.add(s1);
		ts.add(s2);
		ts.add(s3);
		ts.add(s4);
		System.out.println(ts);
	}
}
class StudentHigh implements Comparator<Student>{
	public int compare(Student s1,Student s2){
		return s2.length - s1.length;
	}
}
class Student implements Comparable<Student>{
	String name;
	int score;
	int length;
	public Student(String name,int score,int length){
		this.name = name;
		this.score = score;
		this.length = length;
	}
	public int compareTo(Student s){
		return this.score - s.score;
	}
	public String toString(){
		return name + " " + score + " " + length;
	}
}
```

```java
// Comparator接口可自定义比较规则
import java.util.*;
public class TestB{
	public static void main(String[] args){
		List<String> list = new ArrayList<>();
		Collections.addAll(list,"a","ab","abcd","abc");
		Collections.sort(list,new MyComparator());
		System.out.println(list);
	}
}

class MyComparator implements Comparator<String>{
	public int compare(String o1,String o2){
		if(o1.length()!=o2.length()){
			return o1.length()-o2.length();
		}
		return o1.compareTo(o2);
	}
}
```

内部类方式

```java
import java.util.*;
public class TestB{
	public static void main(String[] args){
		List<String> list = new ArrayList<>();
		Collections.addAll(list,"a","ab","abcd","abc");
		Collections.sort(list,new Comparator<String>(){
			public int compare(String o1,String o2){
				if(o1.length()!=o2.length()){
					return o1.length()-o2.length();
				}
				return o1.compareTo(o2);
			}
		});
		System.out.println(list);
	}
}

class MyComparator implements Comparator<String>{
	public int compare(String o1,String o2){
		if(o1.length()!=o2.length()){
			return o1.length()-o2.length();
		}
		return o1.compareTo(o2);
	}
}
```

Lambda表达式方式

```
import java.util.*;
public class TestB{
	public static void main(String[] args){
		List<String> list = new ArrayList<>();
		Collections.addAll(list,"a","ab","abcd","abc");
		Collections.sort(list,(String s1,String s2) -> s2.length()-s1.length());
		System.out.println(list);

	}
}
```

两者区别

相同点： 两者都可以对集合中的元素进行排序

不同点：comparable称为自然排序或内部排序（嵌入到类中），实现了该接口的类就拥有了比较大小的能力

comparator接口通常被称为外部排序 可自定义排序规则

comparable和comparator接口同时存在时 comparator优先级更高

comparable是java.lang包下

comparator是java.util包下

# Map

Map集合是键值对集合

键值对   -》 key - value

例如 我们要写一个单词拼写检查工具

​	左边是单词  右边是对应的中文含义    apple=苹果   orange=橘子

是整对出现的

## HashMap

```
HashMap是HashTable的升级版，HashTable线程安全 但效率低
HashMap是线程不安全 但效率高
ArrayList线程不安全 效率高，Vector线程安全 效率低

HashMap允许null做为key或value

数组的优点是查询效率高 增删效率低
链表的优点是增删效率低，查询效率高

有没有即查询效率高 又增删效率高的数据结构呢？
数组+链表结构，既有数组的优点 又有链表的优点



```

### 基本用法

```java
import java.util.*;
import java.util.Map.*;
public class TestHashMap{
	public static void main(String[] args){
		// 定义map集合
		// key和value可以是任意数据类型 注意不能是基本数据类型
		Map<String,Student> map = new HashMap<>();
		// 添加元素
		map.put("s1",new Student("Tom",12));
		map.put("s2",new Student("Jerry",13));
		map.put("s3",new Student("Andy",15));
		map.put("s4",new Student("Steve",18));
		// 查看集合中的元素
		System.out.println(map);
		// 获取指定的元素
		Student stu = map.get("s2");
		System.out.println(stu);
		// 删除指定元素 通过key删除
		//map.remove("s1");
		// 清空map集合
		//map.clear();
		// 获取集合中元素个数
		int size = map.size();
		System.out.println(size);
		// 遍历map
		// 方式1 获取map中全部key
		Set<String> set = map.keySet();
		// 通过key获取到value
		for(String k:set){
			System.out.println(map.get(k));
			// 遍历的过程中禁止对集合有任何的增删改操作
			//map.put("s22",new Student("aa",11));
		}

		// 方式2 直接获取值
		Collection<Student> values = map.values();
		for(Student student:values){
			System.out.println(student);
		}

		// 方式3 得到键和值的遍历
		Set<Entry<String,Student>> entry = map.entrySet();
		for(Entry<String,Student> en:entry){
			System.out.println("key="+en.getKey()+" value="+en.getValue());
		}

		// Map集合中 如果key相同 值会被覆盖
		map.put("s1",new Student("Tm2",13));
		System.out.println(map);
	}
}

class Student{
	String name;
	int age;
	public Student(String name,int age){
		this.name = name;
		this.age = age;
	}

	public String toString(){
		return name+","+age;
	}
}
```

键相同 值会被覆盖 那么键是如何认定是相同的

同样需要遵从hashCode和equals比较

```
import java.util.*;
public class TeshHashMap2{
	public static void main(String[] args){
		// 测试键是如何认定为相同的
		Map<Student2,String> map = new HashMap<>();
		map.put(new Student2("Tom",12),"tom");
		map.put(new Student2("Tom",12),"tom");

		System.out.println(map);
	}
}

class Student2{
	String name;
	int age;
	public Student2(String name,int age){
		this.name = name;
		this.age = age;
	}

	public int hashCode(){
		return name.hashCode()+age;
	}

	public boolean equals(Object o){
		if(o == this) return true;
		if(!(o instanceof Student2)) return false;
		Student2 s1 = this;
		Student2 s2 = (Student2)o;
		return s1.name.equals(s2.name);
	}

	public String toString(){
		return name+","+age;
	}
}
```

HashMap的键值都可以为null

```
import java.util.*;
public class TeshHashMap3{
	public static void main(String[] args){
		// 测试键值为null
		Map<Student2,String> map = new HashMap<>();
		map.put(null,"tom");
		map.put(new Student2("Tom",12),"tom");
		map.put(null,null);
		System.out.println(map.get(null));
	}
}
```



## HashTable

基本用法

```java
import java.util.Map.*;
import java.util.*;

public class TestHashTable   {
	public static void main(String[] args){
		// 定义map集合
		// key和value可以是任意数据类型 注意不能是基本数据类型
		Map<String,Student> map = new Hashtable<>();
		// 添加元素
		map.put("s1",new Student("Tom",12));
		map.put("s2",new Student("Jerry",13));
		map.put("s3",new Student("Andy",15));
		map.put("s4",new Student("Steve",18));
		// 查看集合中的元素
		System.out.println(map);
		// 获取指定的元素
		Student stu = map.get("s2");
		System.out.println(stu);
		// 删除指定元素 通过key删除
		//map.remove("s1");
		// 清空map集合
		//map.clear();
		// 获取集合中元素个数
		int size = map.size();
		System.out.println(size);
		// 遍历map
		// 方式1 获取map中全部key
		Set<String> set = map.keySet();
		// 通过key获取到value
		for(String k:set){
			System.out.println(map.get(k));
			// 遍历的过程中禁止对集合有任何的增删改操作
			//map.put("s22",new Student("aa",11));
		}

		// 方式2 直接获取值
		Collection<Student> values = map.values();
		for(Student student:values){
			System.out.println(student);
		}

		// 方式3 得到键和值的遍历
		Set<Entry<String,Student>> entry = map.entrySet();
		for(Entry<String,Student> en:entry){
			System.out.println("key="+en.getKey()+" value="+en.getValue());
		}

		// Map集合中 如果key相同 值会被覆盖
		map.put("s1",new Student("Tm2",13));
		System.out.println(map);
	}
}

class Student{
	String name;
	int age;
	public Student(String name,int age){
		this.name = name;
		this.age = age;
	}

	public String toString(){
		return name+","+age;
	}
}
```





HashMap&HashTable区别

HashMap 默认初始化容量16，加载因子0.75F	遵循2的N次方数 如果我们传入的初始化大小非2的N次方数 会自动转为2的N次方数

HashTable 默认初始化容量11，加载因子0.75F    不遵循2的N次方数



HashTable键值都不允许值为null

HashMap键值都运行为null

HashTable是现场安全的 同时效率相对HashMap低





## ConcurrentHashMap

java.util.concurrent包下  JDK5.0提供

```
高并发下HashMap存在线程安全问题，HashTable虽然是线程安全的 但效率较低
此时JDK给我们提供了一个既可以解决高并发下线程安全问题 又可以提高效率的Map集合ConcurrentHashMap
在JDK7.0之前 使用分段式锁机制，只对需要访问的链表进行加锁，在高并发情况下实现了线程安全
HashTable是将整个链表都进行了加锁 ConcurrentHashMap则采用分段式锁
在JDK8.0 引入自旋锁来替代加锁
自旋锁(spinlock) 是一种无锁状态
什么是自旋锁：
当一个线程尝试去获取某一把锁的时候，如果这个锁已经被另外一个线程占有了，那么此线程就无法获取这把锁，该线程会等待(该线程非线程队列中)，间隔一段时间后再次尝试获取。这种采用循环加锁,等待锁释放的机制就称为自旋锁（spinlock）
为什么需要自旋锁？
由于高并发情况下，很多时侯需要互斥访问，这时候就需要引入锁的概念，只有获取到锁的线程才能对临界资源进行访问，由于多线程的核心是CPU的时分片,所以同一时刻只能又一个线程获取到锁。但是那些没有获取到锁的线程该怎么办呢？
通常有两种方式
一种是没有获取到锁的线程就一直等待判断该资源是否已经释放了锁，这种锁叫做自旋锁,它不会引起线程阻塞（本质上是一种忙等待机制，避免线程切换带来的系统开销）。还有一种是没有获取到锁的线程把自己阻塞起来，重新等待CPU的调度，这种锁称为互斥锁

ConcurrentHashMap在JDK8.0中将分段锁改为了自旋锁的目的就是降低高并发时带来的线程安全问题

自旋锁虽然是一种无锁状态 哪个线程抢到 就归哪个线程使用Map中的数据 但毕竟也是一把锁 只是相对于传统IO模式 都在队列中等待申请锁资源要节省很多 Hashtable采用的就是传统IO模式的锁(互斥锁 也是重量级锁)
```



基本使用

```java
import java.util.Map.*;
import java.util.concurrent.*;
import java.util.*;

public class TestConcurrentHashMap   {
	public static void main(String[] args){
		// 定义map集合
		// key和value可以是任意数据类型 注意不能是基本数据类型
		Map<String,Student> map = new ConcurrentHashMap<>();
		// 添加元素
		map.put("s1",new Student("Tom",12));
		map.put("s2",new Student("Jerry",13));
		map.put("s3",new Student("Andy",15));
		map.put("s4",new Student("Steve",18));
		// 查看集合中的元素
		System.out.println(map);
		// 获取指定的元素
		Student stu = map.get("s2");
		System.out.println(stu);
		// 删除指定元素 通过key删除
		//map.remove("s1");
		// 清空map集合
		//map.clear();
		// 获取集合中元素个数
		int size = map.size();
		System.out.println(size);
		// 遍历map
		// 方式1 获取map中全部key
		Set<String> set = map.keySet();
		// 通过key获取到value
		for(String k:set){
			System.out.println(map.get(k));
			// 遍历的过程中禁止对集合有任何的增删改操作
			//map.put("s22",new Student("aa",11));
		}

		// 方式2 直接获取值
		Collection<Student> values = map.values();
		for(Student student:values){
			System.out.println(student);
		}

		// 方式3 得到键和值的遍历
		Set<Entry<String,Student>> entry = map.entrySet();
		for(Entry<String,Student> en:entry){
			System.out.println("key="+en.getKey()+" value="+en.getValue());
		}

		// Map集合中 如果key相同 值会被覆盖
		map.put("s1",new Student("Tm2",13));
		System.out.println(map);
	}
}

class Student{
	String name;
	int age;
	public Student(String name,int age){
		this.name = name;
		this.age = age;
	}

	public String toString(){
		return name+","+age;
	}
}
```



