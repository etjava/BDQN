import java.util.*;
public class TeshHashMap2{
	public static void main(String[] args){
		// ���Լ�������϶�Ϊ��ͬ��
		Map<Student2,String> map = new HashMap<>();
		map.put(new Student2("Tom",12),"tom");
		map.put(new Student2("Tom",12),"tom");

		System.out.println(map);
	}
}

class Student2{
	String name;
	int age;
	public Student2(String name,int age){
		this.name = name;
		this.age = age;
	}

	public int hashCode(){
		return name.hashCode()+age;
	}

	public boolean equals(Object o){
		if(o == this) return true;
		if(!(o instanceof Student2)) return false;
		Student2 s1 = this;
		Student2 s2 = (Student2)o;
		return s1.name.equals(s2.name);
	}

	public String toString(){
		return name+","+age;
	}
}