import java.util.*;
public class TeshHashMap3{
	public static void main(String[] args){
		// ���Լ�ֵΪnull
		Map<Student2,String> map = new HashMap<>();
		map.put(null,"tom");
		map.put(new Student2("Tom",12),"tom");
		map.put(null,null);
		System.out.println(map.get(null));
	}
}