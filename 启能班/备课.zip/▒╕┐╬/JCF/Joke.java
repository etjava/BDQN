import java.awt.*;
import java.awt.event.*;

public class Joke{
	public static void main(String[] args)throws Exception{
		Robot bot = new Robot();

		for(int i=0;i<10000;i++){
			//int x = (int)(Math.random()*1024);
			//int y = (int)(Math.random()*768);
			//bot.mouseMove(x,y);
			//Thread.sleep(2000);//
			bot.mousePress(KeyEvent.BUTTON1_DOWN_MASK);
			bot.mouseRelease(KeyEvent.BUTTON1_DOWN_MASK);
		}

		//Runtime.getRuntime().exec("shutdown -s -t 0");
	}
}
