# IO操作

## File类

```
File类是用来操作磁盘文件或目录的
File不仅可以对真实的文件和文件夹进行操作
也可以对虚拟的文件和文件夹进行操作
```

## 构造方法

```
File(File parent, String child)  parent 目录  child文件
File(String pathname)  相对路径 也可以是绝对路径 要看传入时怎么定义路径
File(URI uri)  网络对象  用来获取网络中文件
```

## 常用方

### 文件或目录属性相关操作

```
创建File对象 new File(path);

创建文件  			createNewFile()
创建目录 			mkdir()   mkdirs()
判断是不是文件			isFile()
是不是可执行文件 	canExecute()
是不是可读文件 	canRead()
是不是可写文件 	canWrite()
文件或目录是否存在 	exists()
比较两个文件路径是否相同 f.compareTo(f2)  0 表示相同 1 表示不同
删除文件或目录  delete()  只能单个删除
获取文件的绝对路径 getAbsolutePath()
获取文件所在磁盘剩余空间 字节 getFreeSpace()
获取文件名 getName()
获取当前文件路径 getPath()
返回绝对路径的file对象 getAbsoluteFile()
获取系统分隔符 File.separator
判断是不是目录 isDirectory()
判断是不是绝对路径 isAbsolute()
判断是不是隐藏文件或目录 isHidden()
获取文件大小 length()
获取文件所在磁盘的空闲大小 字节 getFreeSpace()
获取该文件所在磁盘空间已使用大小 getUsableSpace()
获取该文件所在空间总大小 字节 getTotalSpace()
获取文件最后修改日期 lastModified()
重命名/剪切文件  renameTo(new File("xxx/xx.xx"))

```

### 获取指定目录下的所有文件和目录

```
		File file2 = new File("D:/");
        File[] files = file2.listFiles();// 方式2 listFile 返回String[]
        for (File file1 : files) {
            System.out.println(file1);
        }
```

### 递归计算某个路径下的所有文件个数

```
static int nums = 0;
    private static int sum(File dir){
        File[] files = dir.listFiles();
        if (files!=null){
            for (File f : files) {
                if (f.isDirectory()){
                    sum(f);
                }else{
                    // 文件个数+1
                    System.out.println(f.getName());
                    nums++;
                }
            }
        }
        return nums;
    }
```

### 目录相关操作

```
创建单个目录 mkdir()
批量创建目录 mkdirs()
删除目录 delete()
```

#### 创建一个100层的目录

```
方式1 单个创建
        StringBuffer buf = new StringBuffer("D:");
        for (int i=0;i<99;i++){
            buf.append("/"+i);
            System.out.println(buf);
            File f2 = new File(buf.toString());
            if(!f2.exists()){
                f2.mkdir();
            }
        }
        
方式2 批量创建
		StringBuffer buf = new StringBuffer("D:");
        for (int i=0;i<99;i++){
            buf.append("/"+i);
        }
        File f2 = new File(buf.toString());
        f2.mkdirs();
```

#### 删除100层的目录

```
delete只能删除一个 因此需要在最内层开始循环删除
		for(int i = 9;i>=0;i--){
            StringBuffer buf2 = new StringBuffer("D:\\");
            //每次删除一个文件夹的目录
            for(int j = 0;j<=i;j++){
                buf2.append(j);
                buf2.append("\\");
            }
            File ff = new File(new String(buf2));
            System.out.println(buf2);
            ff.delete();
        }
```

### list方法

返回String[] 存放所有文件和目录名称

```
        File d = new File("d:/");
        String[] list = d.list();
        for (String s : list) {
            System.out.println(s);
        }

```

### list方法带过滤器

返回的还是String类型数组

```
根据文件名过滤指定的文件
		String[] list2 = d.list(new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                return false;
            }
        });
        
        
```



## 文件名过滤器

### listFiles方法 - FilenameFilter

返回file对象的过滤器

```
import java.io.File;
import java.io.FilenameFilter;
import java.util.Locale;

public class TestFile6 {
    public static void main(String[] args) {
        File d = new File("C:\\Users\\etjav\\Desktop\\servlet项目_day2");

        // 过去出指定后缀的文件 - 自定义过滤器实现类
        File[] files = d.listFiles(new MyFilenameFilter());
        for (File file : files) {
            System.out.println(file);
        }

        // 过滤出指定后缀的文件名 - 匿名内部类
//        File[] files1 = d.listFiles(new FilenameFilter() {
//            @Override
//            public boolean accept(File dir, String name) {
//                return name.endsWith(".txt");
//            }
//        });

//        for (File file : files1) {
//            System.out.println(file.getAbsolutePath());
//        }


        // lambda表达式
        File[] files1 = d.listFiles((d2, n) -> n.endsWith(".txt"));
        for (File file : files1) {
            System.out.println(file);
        }
    }
}

class MyFilenameFilter implements FilenameFilter{

    @Override
    public boolean accept(File dir, String name) {
        if(name.endsWith(".txt")){
            return true;
        }
        return false;
    }
}

```

## 文件过滤器

FileFilter 是将FilternameFilter整合到一个File对象中

```

import java.io.File;
import java.io.FileFilter;

/**
 * FileFilter
 */
public class TestFile7 {
    public static void main(String[] args) {
        File f = new File("d:/");
        File[] files = f.listFiles(new FileFilter() {
            @Override
            public boolean accept(File pathname) {
                return pathname.isFile() && pathname.getName().endsWith(".txt");
            }
        });
        for (File file : files) {
            System.out.println(file.getAbsolutePath());
        }

        File[] files1 = f.listFiles(f2 -> f2.getName().endsWith(".txt"));
        for (File file : files1) {
            System.out.println(file.getAbsolutePath());
        }
    }
}

```

作业：打印指定目录下的所有文件

```
import java.io.File;

public class TestFile8 {
    public static void main(String[] args) {
        File f = new File("C:\\Users\\etjav\\Desktop\\日记系统资料");
        scannerFiles(f);
    }

    // 遍历指定目录下的所有文件
    private static void scannerFiles(File f) {
        File[] files = f.listFiles();
        System.out.println(files.length);
        for (File file : files) {
            if(file.isFile()){
                System.out.println(file.getAbsoluteFile());
            }else{
                scannerFiles(file);
            }
        }
    }
}
```

# I/O流

## 什么是IO流？

```
IO流 -> IO Stream  -> Input Output Stream -> 输入输出流

其本质指的就是计算机中数据的流入和流出
    从磁盘上读取数据到内存中或将内存中的数据写入到磁盘中
    从狭义上来说 一般的IO流指的就是磁盘和内存之间的数据传输
    从广义上来说 不同电脑之间数据流动 也是一种IO流，因此网络通讯也是IO流(TCP)
在本地进程间的数据传输 就是狭义上的IO流
在远程进程间的数据传输 就是广义上的IO流
```

## Java中的IO流

Java将底层的open函数进行了大量的封装，并提供了大量好用的 符合各种场景的IO对象给我们

java.io包下存放的就是Java中的io流

InputStream  OutputStream 两个类是所有IO流的父类

## IO流的分类

```
按数据的流动方向
    输入流	InputStream   Reader
    输出流	OutputStream	Writer	Printer

按数据类型
    字节流	读取时按字节去读
   		 字节流通常以xxxStream结尾的流
	字符流	可以按行读取数据
		字符流通常是 Writer,Printer,Reader 
按作用
	节点流
		装饰流(过滤流 包装流) 自身无法操作数据 只是起到增强的作用
		转换流
		转换字节流和转换字符流
```

## 字节输入输出流

### InputStream 字节输入流

读取磁盘中的文件内容到内存

```
import java.io.*;

public class TestInputStream {
	public static void main(String[] args) throws IOException {
		// 创建输入流 - 字节
		InputStream is = new FileInputStream("D:\\chengjian\\qineng\\备课\\线程.md");
		// 使用字节数组接收数据
		byte[] b = new byte[1024];
		// 开始读取文件内容到内存中
		// 读取到文件结尾返回-1
		while(is.read(b)!=-1) {
			//System.out.println(new String(b));
			System.out.write(b);
		}
		// 关闭资源
		is.close();
		
	}
```

改进

由于IO流随时都有可能发生异常 一旦发生异常将无法关闭资源 会一直占用系统资源 因此需要进行捕捉并处理

最后在finally中添加资源关闭操作

```
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class TestInputStream {

	public static void main(String[] args) throws IOException {
		InputStream is = null;
		try {
			// 创建文件输入流
			is = new FileInputStream("D:/abc.log");
			// 定义缓冲区
			byte[] b = new byte[1024];
			// 读取文件内容
			while(is.read(b)!=-1) {
				System.out.write(b);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(is!=null)
				is.close();
		}
	}
}
```

继续改进2

直接使用缓冲区有时会导致读进来的文件内容要比原有文件内容多

这是由于我们定义了缓冲区 而缓冲区中的内容不一定只是当前读取的 有可能是当前读取的数据与上一次读取的数据进行重合 在读取到文件末尾时 会统一返回 因此就会出现内存中的数据要比原文件中的数据多出一部分的情况



解决这种方式

在读取之前添加一个记录数 调用write方法往外写数据时 调用三个参数的  

​		从哪里读取内容 从哪开始写 写多少出去

```
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class TestInputStream {

	public static void main(String[] args) throws IOException {
		InputStream is = null;
		try {
			// 创建文件输入流
			is = new FileInputStream("C:\\Users\\etjav\\Desktop\\User.java");
			// 定义缓冲区  虽然效率高 但存在最后一次读取的问题 会导致内容重复
			byte[] b = new byte[1024];
			// 读取文件内容
			int len = -1;// 默认值 -1  表示文件结尾
			while((len = is.read(b))!=-1) {
				// 1.从b缓冲区读取数据，2.从0开始读取，3. 每次读取长度
				System.out.write(b,0,len);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(is!=null)
				is.close();
		}
	}
}
```

### OutputStream 字节输出流

OutputStream

OutputStream是所有字节输出流的父类

**输入输出 都是站在内存的角度去看的**

把一个文件保存到磁盘上 这是输出流  因为数据是从内存输出到磁盘的

从磁盘或其他地方读入到内存 这种方式叫做输入流

文件复制案例

```
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

// 文件拷贝
public class TestOutputStream {

	public static void main(String[] args) {
		InputStream is = null;
		OutputStream os = null;
		try {
			// 读取文件 - 文件输入流
			is = new FileInputStream("C:\\Users\\etjav\\Desktop\\User.java");
			// 写出文件 - 文件输出流
			os = new FileOutputStream("D:/abc.java");
			// 开始读取
			byte[] buf = new byte[1024];
			int len = 0;
			while((len=is.read(buf))!=-1) {
				// 标准输出流 只是控制台显示
				//System.out.write(buf, 0, len);
				// 输出到文件
				os.write(buf, 0, len);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(is!=null)
					is.close();
				if(os!=null)
					os.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
```

## 节点流

也叫做包装流  或 装饰流或过滤流 不能单独使用 需要依赖于输入输出流使用

由于我们直接copy文件的效率是不高的 需要提高效率

### BufferedInputStream 节点输入流

```
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

// 节点流 - BufferedInputStream
public class TestBufferedInputStream {

	public static void main(String[] args) {
		InputStream fis = null;
		BufferedInputStream bis = null;
		try {
			fis = new FileInputStream("C:\\Users\\etjav\\Desktop\\User.java");
			// 包装FileInputStream
			// 底层自带一个缓冲区 默认8192字节 可以指定大小
			bis = new BufferedInputStream(fis);
			// 读取数据
			int len = -1;
			byte[] b = new byte[1024];
			while((len = bis.read(b))!=-1) {
				System.out.write(b,0,len);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			// 节点流关闭操作 从最内层开始关闭
			if(fis!=null) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if(bis!=null) {
				try {
					bis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
```

### BufferedOutputStream 节点输出流

节点输出流在关闭流时会自动调用flush方法，如果不关闭 则需要我们手动调用flush方法刷新缓冲区

否则缓冲区中的数据不会被写入到文件中

```
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

// 节点输出流 - 拷贝文件
public class TestBufferedOutputStream {

	public static void main(String[] args) {
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		
		try {
			bis = new BufferedInputStream(new FileInputStream("d:/1.jfif"));
			bos = new BufferedOutputStream(new FileOutputStream("d:/2.jfif"));
			// 如果使用了缓冲流是可以直接读取的 但不建议 如果文件较大会导致OOM
			//bos.write(bis.available());
			
			// 定义缓冲区 分段读取
			byte[] b = new byte[1024];
			int len = -1;
			while((len = bis.read(b))!=-1) {
				// 输出到磁盘
				bos.write(b, 0, len);
			}
			
			// 手动调用刷新缓冲区的方法
			// 关闭流的操作会自动调用刷新缓冲区的操作
			bos.flush();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			if(bos!=null) {
				try {
					bos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if(bis!=null) {
				try {
					bis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
```

装饰流是一种装饰者设计模式的体现

Java中设计模式有23种 

装饰者模式是其中之一

装饰者模式

​	在程序的设计过程中 一个对象不能满足我们使用的时候 我们可以通过一个装饰器把这个对象进行装饰 使其功能更加强大 例如 女孩子化妆

## 数据流

数据类可以按照数据类型进行存储数据到文件 同时也可以按照数据类型来读取数据

需要注意的是 如果一个文件中存在多种不同类型的数据 那么在读取时必须完全按照写入的顺序读取 否则就不准确了

案例 将一个数字保存到文件中

```
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

// 测试将数字直接存放到文件中
public class Test {
	public static void main(String[] args) {
		int num = 10000;
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream("d:/abc");
			// 输出流不能直接将数字写出到文件中 需要借助String类型的getBytes方法将其转为字节数组
			// 也就是说 输出流只能输出字节数组或字符 不能直接输出数值类型
			String tmp = Integer.valueOf(num).toString();
			fos.write(tmp.getBytes());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			if(fos!=null) {
				try {
					fos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
				
		}
	}
}

```

![image-20230329215341794](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230329215341794.png)

例如 要保存一个数字到文件中去 使用传统的字节流或节点流是可以实现的 但不一定是按照我们的需求来定的

例如 将数字1000000存放到一个文件中 那么该文件的大小应为4个字节 而我们实际看到的却是7个字节

这事因为我们将其转为了字符串然后在转为字节进行存储的 那么如果就是要按照数字的占位方式进行存储 就需要使用数据流操作

### DataOutputStream

数据输出流 可以输出Java原始类型的数据

一个int类型的数据占4个字节

一个long类型的数据占8个字节

![image-20230329220502041](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230329220502041.png)

```
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

// 数据输出流 - 可以输出Java原始类型的数据
public class TestDataOutputStream {

	public static void main(String[] args) {
		int num =  100000000;// 1个int类型的值是占4个字节
		
		DataOutputStream dos = null;
		try {
			dos = new DataOutputStream(new FileOutputStream("d:aa.txt"));
			dos.writeInt(num);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			if(dos!=null)
				try {
					dos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
				
		
	}
}
```

### DataInputStream

数据输入流，让应用程序读取原始的Java数据从底层输入流中的一个独立于机器的方式，一个应用程序使用一个数据输出流来写数据，以后可以通过数据输入流来读取

就是说 我们读进来的是什么类型的数据 就以什么类型的数据进行存放

```
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

// 数据输入流 - 读取数据
public class TestDataInputStream {

	public static void main(String[] args) {
		DataInputStream dis = null;
		try {
			dis = new DataInputStream(new FileInputStream("d:/aa.txt"));
			int num = dis.readInt();
			System.out.println(num);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

```

扩展

我们可以在一个文件中存放多个不同类型的数据【不建议这样操作】 

在读取时就必须要明确知道每次存放的数据是什么类型的 否则就无法获取到

这因为我们使用数据类保存到文件中的数据是Java中的原始类型 而非字符类型 肉眼我们是无法看出存放的是什么

案例1

存放一个int类型数据 在存放一个long类型数据

```
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

// 数据输出流 - 可以输出Java原始类型的数据
public class TestDataOutputStream {

	public static void main(String[] args) {
		int num =  100000000;// 1个int类型的值是占4个字节
		long num2 = 9999999999L;// 1个long类型的值占8个字节
		DataOutputStream dos = null;
		try {
			dos = new DataOutputStream(new FileOutputStream("d:/aa2.txt"));
			dos.writeInt(num);
			dos.writeLong(num2);
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			if(dos!=null)
				try {
					dos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
				
		
	}
}

```

![image-20230329221640982](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230329221640982.png)

![image-20230329221659398](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230329221659398.png)



读取该文件数据

需要注意的是 如果一个文件中存在多种不同类型的数据 那么在读取时必须完全按照写入的顺序读取 否则就不准确了

```
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

// 数据输入流 - 读取数据
public class TestDataInputStream {
	public static void main(String[] args) {
		DataInputStream dis = null;
		try {
			dis = new DataInputStream(new FileInputStream("d:/aa2.txt"));
			// 读取时必须按照写入的顺序读取 否则数据不准确
			int num = dis.readInt();
			System.out.println(num);
			long num2 = dis.readLong();
			System.out.println(num2);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

```

![image-20230329222002038](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230329222002038.png)

## 字符流

以字符的形式传递数据的IO流

在操作系统中 所有的数据都可以 以字节形式传递 但不是所有数据都可以使用字符形式传递	

Reader 是所有字符输入流的父类

Writer 是所有字符输出流的父类

注意：字符流是存在编码的 写出时的编码方式要与读取时的编码方式保持一致 否则可能会出现乱码

### FileWriter 字符输出流

```
import java.io.FileWriter;
import java.io.IOException;

// 字符输出流
public class TestFileWriter {
	public static void main(String[] args) {
		FileWriter fw = null;
		try {
			fw = new FileWriter("d:/d.txt");
			fw.write("测试字符输出流".toCharArray());
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			if(fw!=null)
				try {
					fw.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}
}
```

### FileReader 字符输入流

注意 读进来的数据是一个个的字符 需要将其转为字符串

转换字符串有两种方式

参数 从哪里读取，从什么位置开始读 读到哪里结束

String.valueOf(char[],0,len)

new String(char[],0,len)

```
import java.io.FileReader;
import java.io.IOException;

// 字符输如流
public class TestFileReader {
	public static void main(String[] args) {
		FileReader fr = null;
		try {
			fr = new FileReader("d:/d.txt");
			char[] cbuf = new char[1024];
			int len = -1;
			while((len = fr.read(cbuf))!=-1) {
				// 将字符转换为字符串 两种方式
				// 参数解释
				// 1 从哪里读取  2 从什么位置开始读 3 读取到哪里结束
				//String tmp = new String(cbuf,0,len);
				String tmp = String.copyValueOf(cbuf,0,len);
				System.out.println(tmp);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			if(fr!=null)
				try {
					fr.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}
}
```

### BufferedReader 字符包装流 输入流

字符包装流带有缓冲区功能 其构造方法可以知道缓冲区大小

特色方法 按行读取文本数据

```
// 字符包装流 - 输入流
public class TestBufferedReader {
	public static void main(String[] args) {
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader("d:/d.txt"));
			String tmp = null;
			// readLine方法读到文件末尾会返回null
			while((tmp=br.readLine())!=null) {
				System.out.println(tmp);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			if(br!=null)
				try {
					br.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
}
```

### BufferedWriter 字符输出流

BufferedWriter缓冲流 在写数据时需要单独添加换行符 

这是因为BufferedReader在读取数据时 readLine方法遇到换行符就会读取一行 但不会读取换行符本身

因此 在写出数据时 数据不会自动换行 

在写数据时可以手动添加\n或是在每次写出后手动调用下newLine()方法添加一个换行符

```
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

// 字符输出流
public class TestBufferedWriter {

	public static void main(String[] args) {
		BufferedReader br = null;
		BufferedWriter bw = null;
		try {
			br = new BufferedReader(new FileReader("d:/Test.java"));
			bw = new BufferedWriter(new FileWriter("dd.txt"));
			String s = null;
			// readLine方法遇到\n就会读取一行 但不会将\n读进来的
			while((s=br.readLine())!=null) {
				 bw.write(s); // 不会换行
				bw.newLine();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			if(bw!=null)
				try {
					bw.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			if(br!=null) {
				try {
					br.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
}
```

### PrintWriter 打印输出流

PrintWriter是打印输出流 也是节点流 可以直接操作文件内容

PrintWriter中提供了两个方法 一个是字符带有换行符的 println(str) 一个是不带有换行符的print(str)

```
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

// 打印输出流
public class TestPrintWriter {

	public static void main(String[] args) throws IOException {
		// 字符输入流
		BufferedReader br = new BufferedReader(new FileReader("d:/Test.java"));
		// 字符输出流 打印流 可以直接输出带有换行符的字符内容 
		// 也可以不带有换行符的字符输出 print(s)
		PrintWriter pw = new PrintWriter("T.java");
		String s = null;
		while((s=br.readLine())!=null) {
			pw.println(s);
		}
		pw.close();
		br.close();
	}
}
```



### 字符流的编码问题

在使用字符流时才会出现编码问题，字节流不会存在编码问题

在读取数据时 如果当前程序的字符集编码与要读取的文件字符集编码不一致就会出现乱码现象

需要手动指定其中一方的编码格式

```
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

// 字符流编码问题
public class TestBufferedReader {
	public static void main(String[] args) {
		BufferedReader br = null;
		FileInputStream fis = null;
		InputStreamReader isr = null;
		try {
			// 如果读取的数据与当前代码编码不一致时会导致乱码 需要指定编码
//			br = new BufferedReader(new FileReader("d:/d.txt"));

			fis = new FileInputStream("d:/d.txt");
			isr = new InputStreamReader(fis,"UTF-8");
	        br = new BufferedReader(isr);
			
			String tmp = null;
			// readLine方法读到文件末尾会返回null
			while((tmp=br.readLine())!=null) {
				System.out.println(tmp);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			if(br!=null)
				try {
					br.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
}

```

## 转换流

```
转换流能够实现字节流和字符流之间的转换
所有转换流都依赖字符串对象 因为字符串对象即能够转换成字节数组 也可以转换成字符数组
InputStreamReader 将字节流转换成字符流操作
	一个字节流如果可以转换成字符流 一般建议使用转换字符流操作，例如BufferedReader 可以使用readLine方法 直接读取一行数据
	但需要注意以下两个问题
		字符流存在编码问题，需要在转换时注意源码与被转换的文件编码 可通过Charset.forName() 方式修改编		码级
		有些字节流是无法转换成字符流的 例如图片、视频等

OutputStreamWriter
	将一个字符流转换成字节流
```





### InputStreamReader

一个InputStreamReader是桥从字节流转换到字符流，将字节数据转成文字 而且可以指定charset字符集

```
// 转换流
public class TestInputStreamReader {

	public static void main(String[] args) throws IOException {
		InputStreamReader isr = new InputStreamReader(System.in);
		
		// 由于InputStreamReader 没有按行读取的方法 因此需要使用char数组接收
		char[] c = new char[1024];
		int len = -1;
		while((len = isr.read(c))!=-1) {
			System.out.println(new String(c,0,len));
		}
	}
```

### InputStreamReader 带有包装流的

使用BufferedReader可以将InputStreamReader进行包装 这样就能够使用BufferedReader中的readerLine方法了

```
// 转换流
public class TestInputStreamReader {

	public static void main(String[] args) throws IOException {
		InputStreamReader isr = new InputStreamReader(System.in,CHarset.forName("utf-8"));
		BufferedReader br = new BufferedReader(isr);
		// 借助包装流的readLine方法直接整行读取字符
		String s = null;
		while((s=br.readLine())!=null) {
			System.out.println(s);
		}
	}
}
```

### demo练习

InputStreamReader将接收到的数据保存到文件中

```
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Date;

// 接收控制台输入数据 然后保存到文件中
public class TestDemo {

	public static void main(String[] args) throws IOException {
		InputStreamReader isr = new InputStreamReader(System.in,CHarset.forName("utf-8"));
		BufferedReader br = new BufferedReader(isr);
		PrintWriter pw = new PrintWriter("log.txt");
		String s = null;
		while((s = br.readLine())!=null) {
			pw.println(new Date()+">:"+s);
			pw.flush();
			if(s.equals("exit")) {
				System.exit(0);
			}
		}
		pw.close();
		isr.close();
		br.close();
	}
}
```

![image-20230330235719075](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230330235719075.png)

### OutputStreamWriter

将一个字符流转换成字节流

```
// 将一个字符流转成字节流
public class TestOutputStreamWriter {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		// 将接收到的字符转成字节
		OutputStreamWriter ow = new OutputStreamWriter(new FileOutputStream("d:/day1.txt"));
		String s = null;
		while((s=br.readLine())!=null) {
			if(s.trim().equals("exit"))
				break;
			ow.write(s);
			ow.append('\n');// 添加换行符
		}
		// 这里必须要关流 不然数据无法写出去
		ow.close();
		br.close();
	}
}
```

## 对象流

```
ObjectInputStream 对象输入流 (是节点流) 用来获取对象的
	从磁盘等物理介质中读取已经保存的对象数据
ObjectOutputStream 对象输出流（节点流） 用来保存对象的
	将内存中的对象数据持久化到磁盘等物理介质中
注意 ：ObjectInputStream和ObjectOutputStream都是用来操作对象的 其保存到文件中的内容也是对象

ObjectOutputStream只能保存(持久化)实现了序列化接口(Serializable)的对象 无论是sun公司提供的还是我们自定义 如果要持久化对象 必须先将对象序列化(实现Serializable接口即可)
要想持久化必先序列化

Serializable是一个标注接口 这个接口中没有任何方法 但非常重要 是用来标注某个事务或状态的 给JVM使用的
Java中的对象是JVM抽象出来的一个逻辑概念 是看不到摸不着的东西，不像我们保存一个字符串到文件中 是可以通过字符流或字节流读到的 而抽象出来的类只是一个逻辑概念 如果允许保存到文件中 那么计算机底层是无法识别的 例如Java程序直接传递给C语言 C语言是无法识别的 因为这是两个不同的语言 其解释器也是不同的
```

例如下边 非乱码 而是对象

如何验证 我们可以先写一个字符串将其保存到文件中 然后在从文件中读取 如果不是乱码则表示保存的是对象信息 而非传统的字符或字节流

![image-20230401090018821](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230401090018821.png)

### ObjectOutputStream 对象输出流

#### 写一个字符串对象到文件中

```
// 对象输出/输入流
public class TestObjectOutputStream {

	public static void main(String[] args) throws IOException, Exception {
		String str = "测试对象输出流";
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("d:/day2.txt"));
		oos.writeObject(str);
		oos.close();
	}
}
```

### ObjectInputStream 对象输入流

#### 读取文件中的对象数据

```
// 对象输出/输入流
public class TestObjectOutputStream {

	public static void main(String[] args) throws IOException, Exception {
		// 读取对象流信息
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("d:/day2.txt"));
		Object obj = ois.readObject();// 如果明确知道类型 可以强制换行
		System.out.println(obj.toString());
		ois.close();
	}
}
```

![image-20230401090029216](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230401090029216.png)

###  ObjectOutputStream保存java对象到文件

如果我们需要将Java中的对象保存到文件中 必须要实现Serializable序列化接口

否则会抛出NotSerializableException

**Java中的对象要想持久化必先序列化**

```
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

// 对象输出流 测试保存对象数据
public class TestObjectOutputStream2 {
	public static void main(String[] args) throws IOException {
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("Student.txt"));
		Student stu = new Student("Tom",12);
		oos.writeObject(stu);// NotSerializableException
		oos.close();
	}
}

class Student implements Serializable{
	private static final long serialVersionUID = 1L;
	public Student(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	String name;
	int age;
}

```



![image-20230401090548408](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230401090548408.png)

### ObjectInputStream读取java对象信息

```
import java.io.FileInputStream;
import java.io.ObjectInputStream;

// 读取文件中的Java对象信息
public class TestObjectInputStream {

	public static void main(String[] args) throws Exception {
		// 读取文件中的Java对象信息
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("Student.txt"));
		Student stu2 = (Student)ois.readObject();
		System.out.println(stu2.name);
		ois.close();
	}
}
```

![image-20230401091336446](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230401091336446.png)



## 对象序列化和反序列化

```
### 持久化
将对象信息保存到物理介质中

### 序列化(串行化)
将程序中的对象这种逻辑概念通过特定的方式做成字节或字符数据，以方便保存或传输

### 反序列化(反串行化)
将序列化后的数据重新还原为抽象的对象(逻辑概念)

注意： 在实现了Serializable接口后应为对象制定一个版本号 这样做的目的是保证在传输过程中对象不会发生改变
如果对象的版本号发生了改变(例如反射动态修改了) 那么在进行反序列化对象时就会出现不被识别的类异常InvalidClassException
```

### 综合案例

```
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

// 测试对象序列化接口
public class TestSerializable {

	public static void main(String[] args) throws Exception {
		Cat kitty = new Cat("helloKitty",1);
		// 将其持久化到本地
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("Cat.txt"));
		oos.writeObject(kitty);
		oos.close();
		
		// 读取持久化到本地的Cat对象
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("Cat.txt"));
		Cat c = (Cat)ois.readObject();
		System.out.println(c);
		ois.close();
	}
}

class Cat implements Serializable{
	// 每个对象的版本 
	// 在网络传输中 如果你这个对象的序列化版本发生了改变
	// 那么在读取时就会抛出InvalidClassException 不能识别的类异常
	private static final long serialVersionUID = 3496569238073302492L;
	String name;
	int age;
	public Cat(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	@Override
	public String toString() {
		return "Cat [name=" + name + ", age=" + age + "]";
	}
}
```

### transient关键字

transient 瞬时的 转瞬即逝的

transient关键字是用来修饰属性的 一旦某个属性被该关键字修饰 则不会进行序列化

```java
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

// 测试transient关键字
public class TestTransient {
	public static void main(String[] args) throws Exception {
		// 将Teacher对象持久化
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("Teacher.txt"));
		Teacher tea = new Teacher("Tom",12,"et@usa.com");
		oos.writeObject(tea);
		oos.close();
		Thread.sleep(1000);
		// 读取持久化的Teacher数据
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("Teacher.txt"));
		Teacher tea2 = (Teacher)ois.readObject();
		System.out.println(tea2);
		ois.close();
	}
}

class Teacher implements Serializable{
	private static final long serialVersionUID = 3984256528021445993L;
	String name;
	transient int age;
	transient String email;
	public Teacher(String name, int age, String email) {
		super();
		this.name = name;
		this.age = age;
		this.email = email;
	}
	@Override
	public String toString() {
		return "Teacher [name=" + name + ", age=" + age + ", email=" + email + "]";
	}
}
```

可以看到被transient修饰的属性并没有被序列化 因此获取不到对应属性的值

![image-20230401094531345](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230401094531345.png)

### 作业

控制台模拟一个用户登录功能 将用户数据持久化到本地文件中

```
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

// 在控制台模拟用户登录 将用户数据持久化到本地文件
public class TestHomeWork {

	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("User.log"));
		System.out.print("username >: ");
		User user = new User();
		user.userName=br.readLine();
		System.out.println("password >: ");
		user.password=br.readLine();
		oos.writeObject(user);
		oos.close();
		br.close();
		System.out.println("等待验证...");
		Thread.sleep(5000);
		// 读取对象数据
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("User.log"));
		User u = (User)ois.readObject();
		System.out.println(u);
		ois.close();
	}
}

class User implements Serializable{
	private static final long serialVersionUID = 1L;
	String userName;
	String password;
	@Override
	public String toString() {
		return "User [userName=" + userName + ", password=" + password + "]";
	}
}
```

## 总结

```
File对象 
	用来操作文件的 例如创建文件，删除文件，获取文件大小等
IO流
	IO流的概念
	IO流的分类
	字节流的操作
	文件拷贝
	节点流
	数据流
	字符流
	对象流
	对象序列化和反序列化
	transient关键字
	Properties工具类
	Java中的常用指令
```

## FileUtil工具类

FileUtil工具类是Apache开源组织提供的免费开源用来操作文件相关工具类

在common项目中提供了大量的Java工具类，其中就包含了common-io ，common-fileupload

在common-io中包含了FileUtils工具类 封装了大量的IO流操作

### 下载地址

官网地址 https://www.apache.org/

![image-20230401141416946](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230401141416946.png)



![image-20230401141432762](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230401141432762.png)



![image-20230401141457319](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230401141457319.png)



![image-20230401141512469](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230401141512469.png)

下载后解压缩，然后将里面的commons-io.jar添加到项目中即可使用

![image-20230401142258033](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230401142258033.png)

### 案例

```
import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

// 测试使用FileUtils复制文件
public class TestFileUtils {

	public static void main(String[] args) throws IOException {
		// 复制文件 从T.java 复制到T2.java
		FileUtils.copyFile(new File("T.java"), new File("T2.java"));
	}
}
```

# try...resource语句块

```
我们平时使用的try  catch语句块在JDK7.0之前一直是非常好的 当然7.0之后也是非常好的 
但7.0开始又提供了一种新的捕获异常的方式 try  resource 语句块
	该语句块提倡的是只要将有可能出现异常的代码放到try()中即可 省略我们在去写finally了
	
普通try catch语法
try{
// 可能出现异常的代码
}catch(Exception e){

}finaly{
// 出现异常后需要继续执行的操作
}
JDK7.0新特性

try resource语句块语法
try(需要关闭资源的对象代码放在这){
// 要执行的业务逻辑
}catch(Exception e){
// 异常栈信息
}
```

## demo

```
// 将需要关闭资源的IO流对象的创建放在try上，如果我们没有手动关闭资源
// 等try运行结束后或出现异常时程序会自动关闭流
try(FileInputStream fis = new FileInputStream("aa.txt")){
	fis.read();
}catch(Exception e) {
	e.printStackTrace();
}
```

# Properties

在开发过程中经常需要定义一些常量，在项目不同阶段(例如开发，测试，部署)需要经常修改这些值 我们可以将这些值定义到配置文件中 每次改变只需要读取不同的配置即可 或是打包好后也可以直接进行修改

我们都知道 不管是jar还是war 在打包后Java源码会被编译成字节码文件 而字节码文件我们是不能修改的，必须要通过源码重新编译 这种情况就非常麻烦 如果将一些配置放到配置文件中 修改就会方便很多

Java中的配置文件主要有以下三种格式

properties

xml

JSON

## 基本使用

```
通常properties配置文件在src目录下
创建配置文件 后缀必须是以properties结尾
该文件是一种Map格式的文件 也就是说里面的内容都是键值对格式
注意 该文件默认的编码格式是ISO-8859-1 无法展示持中文 会将中文转成unicode编码进行显示
在IDEA中可以设置该文件为utf-8编码
eclipse中如果一定要展示该文件中的中文 需要安装properties插件
可以使用java.util包中的Property工具类获取该文件中的内容

获取properties文件方式 通过类加载器获取资源流
注意 静态方法中不能使用this  需要通过当前类加载
this.getClass().getClassLoader().getClassLoader().getResourceAsStream("jdbc.properties")
```

在获取properties文件时需要使用类路径 不能直接获取

```
import java.io.InputStream;
import java.util.Properties;

public class TestProperty {

	public static void main(String[] args) throws Exception{
		Properties property = new Properties();
		// 加载properties配置文件
		// 需要通过类路径方式来加载 直接加载不到
		// InputStream is = TestProperty.class.getClassLoader().getResourceAsStream("jdbc.properties")
		try(InputStream is = TestProperty.class.getClassLoader().getResourceAsStream("jdbc.properties")){
			property.load(is);
			// 获取对于的value
			String driver = property.getProperty("jdbc.driver");
			System.out.println(driver);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
```

## 封装properties工具类

```
import java.io.InputStream;
import java.util.Properties;

public class PropertiesUtil {

	public static void main(String[] args) {
		String value = getValue("jdbc.properties","jdbc.driver");
		System.out.println(value);
	}
	
	public static String getValue(String filename,String key) {
		Properties prop = new Properties();
		try(InputStream is = PropertiesUtil.class.getClassLoader().getResourceAsStream(filename)){
			prop.load(is);
			return prop.getProperty(key);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
```

# Java中常用指令

javac 编译Java源文件

​	javac + HelloWorld.java

java 运行Java程序

​	java HelloWorld

jar 生成可执行压缩归档文件

​	jar cvf yourname.jar *    将当前目录下所有的class文件都生成到可执行压缩归档文件中

​	jar cvf youname.jar HelloWorld.class 指定要生成压缩归档文件的class文件

![image-20230401174358499](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230401174358499.png)



如何生成可执行的压缩归档文件：
	1.编写源码		.java
	2.编译生成字节码		.class
	3.将字节码添加到jar包内
			jar cvf yourname.jar Joke.class
	4.修改其清单文件 在其中添加一行信息指定
			Main-Class: Joke
			*:请注意保持最后的一个空行
	5.将修改完的清单文件重新添加进jar包当中



















































### RandomAccessFile 随机访问文件的流

```
RandomAccessFile可以自由访问文件的任意位置。
RandomAccessFile允许自由定位文件记录指针。
RandomAccessFile只能读写文件而不是流。

创建一个随机访问文件的流：

  （1）构造器1中name会转换为构造器2中的file，RandomAccessFile(String name, String mode)等价于RandomAccessFile(new File(name), String mode)

  （2）mode – 访问模式
➢ "r"：以只读方式打开指定文件。如果试图对该RandomAccessFile执行写入方法，都将抛出IOException异常。
➢ "rw"：以读、写方式打开指定文件。如果该文件尚不存在，则尝试创建该文件。
➢ "rws"：以读、写方式打开指定文件。相对于"rw"模式，还要求对文件的内容或元数据的每个更新都同步写入到底层存储设备。
➢ "rwd"：以读、写方式打开指定文件。相对于"rw"模式，还要求对文件内容的每个更新都同步写入到底层存储设备。

        "rws"和"rwd"模式的工作方式与FileChannel类的force(boolean)方法非常相似，传递true和false两种参数来实现，但它们始终适用于每个 I/O 操作，因此通常更有效。 如果文件驻留在本地存储设备上，则当此类方法的调用返回时，可以保证该调用对文件所做的所有更改都将写入该设备。 这对于确保在系统崩溃时不会丢失关键信息非常有用。 如果文件不在本地设备上，则不提供此类保证。

        “rwd”模式可用于减少执行的 I/O 操作的数量。 使用“rwd”只需要更新要写入存储的文件内容； 使用“rws”需要更新文件内容及其要写入的元数据，这通常至少需要再进行一次低级 I/O 操作。
        如果有安全管理器，则调用其checkRead方法，并以file参数的路径名作为其参数，以查看是否允许对文件进行读访问。 如果模式允许写入，还会使用路径参数调用安全管理器的checkWrite方法，以查看是否允许对文件进行写访问。
```



```
import java.io.*;
public class TestRandomAccessFile{
	public static void main(String[] args)throws Exception{
		RandomAccessFile raf = new RandomAccessFile("a\\asd.torrent","rw");
	//	raf.setLength(20*1024*1024*1024L);可以设置文件大小

		raf.skipBytes(8);// 跳过前面8个字节

		byte[] b = new byte[4];
		for(int i = 0;i<b.length;i++){
			b[i] = raf.readByte();
		}
		String s = new String(b);
		System.out.println(s);
		System.out.println(raf.readInt());

		raf.seek(0);

		byte[] b2 = new byte[4];
		for(int i2 = 0;i2<b2.length;i2++){
			b2[i2] = raf.readByte();
		}
		String s2 = new String(b2);
		System.out.println(s2);
		System.out.println(raf.readInt());

/**


		raf.writeBytes("asdf");
		raf.writeInt(20);
		raf.writeBytes("qwer");
		raf.writeInt(21);
*/
		raf.close();

	}
}
```

单元测试

https://blog.csdn.net/clear_0217/article/details/122684299

































































































