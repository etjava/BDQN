import java.io.*;
public class Delete{
	public static void main(String[] args){
		File f = new File(".");
		File[] files = f.listFiles((d,n)-> n.toLowerCase().endsWith(".class"));
		for(File file : files)
			file.delete();
	}
}