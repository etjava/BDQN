# GUI

## 介绍

```
GUI是什么？
	GUI是图形用户界面编程
	GUI程序是带有图形界面的Java程序
怎么用？
	组件
	窗口、弹窗、面板、文本框、列表框、按钮、图片、监听事件、鼠标事件、键盘事件
用在什么地方？
	GUI可以做破解工具，外挂（只能检测到JVM 不会检测到实际的应用程序）等
怎么学？
	GUI的核心组件： Swing、ATW

扩展
	之所以现在使用GUI的比较少 其主要原因是页面不美观，需要JRE运行环境（玩一个5M的游戏需要下载安装几十M的环境）

我们为什么要学习？
	1. 可以写出自己心中想要的一些小工具
	2. 工作的时候也可能会维护到swing页面 概率极小
	3. 是MVC的基础 - 监听
	
```

## AWT

```
AWT - Abstract Window Tools 抽象的窗口工具
	包含了很多的类和窗口 例如 new Button 会出现一个按钮，new Fream 会出现一个弹窗等
	
```

 ![image-20230602000044907](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306020000452.png)

### Frame弹窗

#### 第一个窗口程序

```java
import java.awt.*;

// 第一个GUI程序
public class TestFrame {
    public static void main(String[] args) {
        // 定义窗体组件 Frame
        Frame frame = new Frame("第一个GUI程序");
        // 设置窗体的可见性 默认是内存中的 不可见的
        frame.setVisible(true);
        // 设置窗口大小
        frame.setSize(500,300);
        // 弹窗的初始位置 默认在左上角
        frame.setLocation(500,200);
        // 设置弹窗的背景颜色
        frame.setBackground(new Color(86, 183, 55));
        //frame.setBackground(Color.BLACK);
        // 设置窗口固定大小
        frame.setResizable(false);

    }
}

```

![image-20230602001952707](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306020019615.png)

#### 打开多窗口

```java
import java.awt.*;
public class TestFrame2 {
    public static void main(String[] args) {
        new MyFrame(100,100,300,200,Color.red);
        new MyFrame(100,300,300,200,Color.blue);
        new MyFrame(400,100,300,200,Color.green);
        new MyFrame(400,300,300,200,Color.yellow);
    }
}

// 封装弹窗
class MyFrame extends Frame{
    static int id=0;// 窗口计数器 因为可能存在多个窗口 每弹出一个加1

    /**
     *
     * @param x
     * @param y
     * @param w  宽度
     * @param h  高度
     * @param color 背景色
     */
    public MyFrame(int x,int y,int w,int h,Color color){
        // 调用Frame构造方法 设置窗口title 每次弹出一个窗口id+1
        super("第 "+(++id)+" 个窗口");
        // 设置窗口可见性  由于直接继承了Frame 因此可以直接使用父类中的公共方法
        setVisible(true);
        // 设置窗口大小
        setBounds(x,y,w,h);
        // 设置窗口背景色
        setBackground(color);
        // 设置固定大小
        setResizable(false);
    }
}
```

![image-20230602003855254](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306020038551.png)

### 面板弹窗

```
面板(Panel) 可以看成一个空间 但是不能单独存在 需要配合Frame使用
```



```java

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// Panel弹窗
// Panel不能单独使用 需要放到Frame中
public class TestPanel {
    public static void main(String[] args) {
        // 创建Frame
        Frame frame = new Frame();
        // 布局
        Panel panel = new Panel();
        // 设置弹窗布局
        frame.setLayout(null);
        // 设置坐标
        frame.setBounds(300,300,500,500);
        // 设置背景色
        frame.setBackground(new Color(86, 183, 55));
        // 设置Panel坐标 是相对于frame窗体的坐标
        panel.setBounds(50,50,400,400);
        // 设置panel的背景色
        panel.setBackground(new Color(166, 64, 51));
        // 弹窗中添加panel布局
        frame.add(panel);
        // 设置窗体可见
        frame.setVisible(true);
        // 设置窗口固定大小
        frame.setResizable(false);
        // 窗口关闭事件
        // WindowAdapter是WindowListener实现类 因此可以直接拿来使用
        // 如果不使用其实现类则需要重写所有的创建监听事件
        // 这种模式被称之为适配器模式
        frame.addWindowListener(new WindowAdapter() {
            // 窗口关闭时要做的事情
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);// 正常退出程序
            }
        });
    }
}

```

![image-20230602072421826](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306020724579.png)

#### 布局

##### 流式布局(默认)

可以通过FlowLayout进行布局限制 例如按钮居中，居左或居右等

```java

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 流式布局
public class TestFlowLayout {

    public static void main(String[] args) {
        // 定义窗体
        Frame frame = new Frame();
        // 定义按钮组件
        Button btn1 = new Button("button1");
        Button btn2 = new Button("button1");
        Button btn3 = new Button("button1");

        // 设置为流式布局
        //frame.setLayout(new FlowLayout());
        frame.setLayout(new FlowLayout(FlowLayout.LEFT));// 居左

        // 给窗体添加按钮
        frame.add(btn1);
        frame.add(btn2);
        frame.add(btn3);

        // 设置窗体背景色
        frame.setBackground(new Color(78, 210, 38));
        // 设置窗体大小
        //frame.setSize(200,200);
        frame.setBounds(200,200,300,300);
        // 设置窗体可见
        frame.setVisible(true);


        // 关闭窗口事件
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);// 结束程序
            }
        });
    }

}

```

![image-20230602075131231](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306020751392.png)

##### 表格布局

```java

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 表格布局
public class TestGridLayout {

    public static void main(String[] args) {
        // 创建窗体
        Frame frame = new Frame();
        // 创建按钮 测试表格布局
        Button btn1 = new Button("btn1");
        Button btn2 = new Button("btn2");
        Button btn3 = new Button("btn3");
        Button btn4 = new Button("btn4");
        Button btn5 = new Button("btn5");
        Button btn6 = new Button("btn6");
        // 给按钮添加背景色
        btn1.setBackground(new Color(78, 210, 38));
        btn3.setBackground(new Color(38, 210, 164));
        btn5.setBackground(new Color(78, 210, 38));
        btn2.setBackground(new Color(38, 210, 164));
        btn4.setBackground(new Color(78, 210, 38));
        btn6.setBackground(new Color(38, 210, 164));
        // 将按钮添加到表格中
        frame.setLayout( new GridLayout(3,2));// 3行2列的表格
        // 将表格添加到窗体中
        frame.add(btn1);
        frame.add(btn2);
        frame.add(btn3);
        frame.add(btn4);
        frame.add(btn5);
        frame.add(btn6);

        // 设置自动布局
        frame.pack();
        // 设置窗体的打开位置
        frame.setBounds(200,200,300,300);

        // 设置窗体可见
        frame.setVisible(true);

        // 设置可关闭
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}

```

![image-20230602100436939](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230602100436939.png)

##### 东南西北中布局

通常作为整体界面的布局 例如上边是导航栏 左边是菜单栏 下边是版本信息 中间是内容区域

```java

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 东南西北中布局方式
public class TestBorderLayout {

    public static void main(String[] args) {
        // 创建窗体
        Frame frame = new Frame();
        // 创建按钮组件
        Button east = new Button("East");// 东
        Button west = new Button("West");// 西
        Button south = new Button("South");// 南
        Button north = new Button("North");// 北
        Button center = new Button("Center");// 中
        // 将按钮添加到窗体中
        frame.add(east,BorderLayout.EAST);
        frame.add(west,BorderLayout.WEST);
        frame.add(south,BorderLayout.SOUTH);
        frame.add(north,BorderLayout.NORTH);
        frame.add(center,BorderLayout.CENTER);

        // 设置窗体固定大小
        frame.setResizable(false);
        // 设置窗体背景色
        frame.setBackground(new Color(78, 210, 38));
        // 设置窗体可见
        frame.setVisible(true);
        // 设置窗体大小及弹窗位置
        frame.setBounds(200,200,300,300);
        // 设置可关闭
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}

```

![image-20230602094840471](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306021006251.png)



##### 作业练习

实现如下效果

![image-20230602101011528](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306021010876.png)

```java
思路：
   frame中使用面板嵌套表格
   分析：
      左右布局 中间为嵌套面板
    	左边 button
    	中间 面板
    	右边 button
    
```

```java

import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 复杂布局作业
public class TestLayout {

    public static void main(String[] args) {
        // 创建总窗体
        Frame frame = new Frame("布局作业");
        // 设置总窗体的布局 - 表格布局
        frame.setLayout(new GridLayout(2,1));

        
        // 定义上边两个面板
        Panel p1 = new Panel(new BorderLayout());
        // 中间面板
        Panel p2 = new Panel(new GridLayout(2,1));
        // 添加到表格布局
        p1.add(new Button("East-1"), BorderLayout.EAST);// 左边
        p1.add(new Button("West-1"), BorderLayout.WEST);// 右边
        p2.add(new Button("p2-btn-1"));// 中间的上边
        p2.add(new Button("p2-btn-2"));// 中间的下边
        // 把p2面板添加到p1中 放在中间位置
        p1.add(p2,BorderLayout.CENTER);
        // 定义下边两个面板
        Panel p3 = new Panel(new BorderLayout());
        // 中间面板
        Panel p4 = new Panel(new GridLayout(2,2));
        p3.add(new Button("East-2"), BorderLayout.EAST);// 左边
        p3.add(new Button("West-2"), BorderLayout.WEST);// 右边
        // 中间的4个面板
        for (int i = 0; i < 4; i++) {
            p4.add(new Button("p3-btn-"+i));
        }
        // 把p4面板添加到p3中
        p3.add(p4,BorderLayout.CENTER);

        /*
            将面板添加到frame中
            p2面板放到p1中，p4放到p3中 因此只需要添加两个面板到frame中即可
         */
        frame.add(p1);
        frame.add(p3);
        // 设置窗体可见
        frame.setVisible(true);
        // 设置背景色
        frame.setBackground(Color.BLACK);
        // 设置总窗体大小
        frame.setSize(600,400);
        // 设置弹出位置
        frame.setLocation(300,200);
        // 窗体可关闭
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}

```

![image-20230602111523430](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306021115968.png)

##### 作业2

![image-20230602143513413](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230602143513413.png)

```java

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 作业2
public class TestWork2 {

    public static void main(String[] args) {
        Frame frame = new Frame();
        // 表格布局
        frame.setLayout(new GridLayout(3,1));
        Panel p1 = new Panel(new BorderLayout());
        Panel p2 = new Panel(new GridLayout(1,2));
        Panel p3 = new Panel(new BorderLayout());
        p2.add(new Button("East"),BorderLayout.EAST);
        p2.add(new Button("West"),BorderLayout.WEST);

        // 设置面板背景色
        p1.setBackground(Color.RED);
        p3.setBackground(Color.GREEN);


        // 将面板添加到窗体中
        frame.add(p1);
        frame.add(p2);
        frame.add(p3);
        // 设置窗体可见
        frame.setVisible(true);
        // 按钮自动布局
        frame.pack();
        // 窗体弹出位置
        frame.setBounds(300,200,600,400);
        // 设置窗体可关闭
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}
```



![image-20230602144501068](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230602144501068.png)

##### 布局小结：

```
Frame 是一个顶级窗口
	注意 不能嵌套
	
Panel 是面板 不能单独使用 需要添加到容器中 例如Frame

布局管理器
	1. 流式布局
	2. 表格布局
	3. 东西南北中布局
	
组件的大小、定位、背景色、可见性、监听
```

### 监听



















































































































