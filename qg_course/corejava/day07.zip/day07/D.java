import java.io.*;
public class D{
	public static void main(String[] args){
		File f = new File(".");
		File [] files = f.listFiles(new FilenameFilter(){
			public boolean accept(File d,String name){
				return name.toLowerCase().endsWith(".class");
			}
		});

		for(File file:files)
			file.delete();
	}
}