// HashSetɾ��Ԫ��ʱ ֻ���϶��ظ� �Ż�ɾ��
import java.util.*;
public class TestHashSet05{
	public static void main(String[] args){
		HashSet<Student> set = new HashSet<>();
		Student stu = new Student("Tom");
		set.add(stu);
		System.out.println(set.size());// 1
		set.remove(stu);
		System.out.println(set.size());//0  �ȱȽ�hashCode �õ���ͬ��hash  Ȼ�����ȱȽϷ���true
	}
}
class Student{
	String name;
	public Student(String name){
		this.name = name;
	}

	@Override
	public int hashCode(){
		return (int)(Math.random()*2);
	}

	@Override
	public boolean equals(Object obj){
		return false;
	}
	@Override
	public String toString(){
		return name;
	}
}