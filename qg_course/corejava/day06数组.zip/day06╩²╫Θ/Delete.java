import java.io.*;
import javax.swing.*;
public class Delete{
	public static void main(String[] args){
		String dir = JOptionPane.showInputDialog("����Ҫɾ����·��","");
		File f = new File(dir);
		File[] files = f.listFiles(new FilenameFilter(){
			public boolean accept(File d,String name){
				return name.toLowerCase().endsWith(".class");
			}
		});

		for(File f2:files){
			System.out.println(f2.getName());
			f2.delete();
		}

	}
}