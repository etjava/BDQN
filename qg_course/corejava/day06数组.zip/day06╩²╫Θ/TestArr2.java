public class TestArr2{
	public static void main(String[] args){
		// ��̬����1
		int[] arr = new int[]{1,2,3,55,66};

		for(int i=0;i<arr.length;i++){
			System.out.print(arr[i]+"  ");
		}
		System.out.println("-----------");

		System.out.println("arr[]��С��"+arr.length);
	}

}