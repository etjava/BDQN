# GUI

## 介绍

```
GUI是什么？
	GUI是图形用户界面编程
	GUI程序是带有图形界面的Java程序
怎么用？
	组件
	窗口、弹窗、面板、文本框、列表框、按钮、图片、监听事件、鼠标事件、键盘事件
用在什么地方？
	GUI可以做破解工具，外挂（只能检测到JVM 不会检测到实际的应用程序）等
怎么学？
	GUI的核心组件： Swing、ATW

扩展
	之所以现在使用GUI的比较少 其主要原因是页面不美观，需要JRE运行环境（玩一个5M的游戏需要下载安装几十M的环境）

我们为什么要学习？
	1. 可以写出自己心中想要的一些小工具
	2. 工作的时候也可能会维护到swing页面 概率极小
	3. 是MVC的基础 - 监听
	
```

## AWT

```
AWT - Abstract Window Tools 抽象的窗口工具
	包含了很多的类和窗口 例如 new Button 会出现一个按钮，new Fream 会出现一个弹窗等
	
```

 ![image-20230602000044907](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306020000452.png)

### Frame弹窗

#### 第一个窗口程序

```java
import java.awt.*;

// 第一个GUI程序
public class TestFrame {
    public static void main(String[] args) {
        // 定义窗体组件 Frame
        Frame frame = new Frame("第一个GUI程序");
        // 设置窗体的可见性 默认是内存中的 不可见的
        frame.setVisible(true);
        // 设置窗口大小
        frame.setSize(500,300);
        // 弹窗的初始位置 默认在左上角
        frame.setLocation(500,200);
        // 设置弹窗的背景颜色
        frame.setBackground(new Color(86, 183, 55));
        //frame.setBackground(Color.BLACK);
        // 设置窗口固定大小
        frame.setResizable(false);

    }
}

```

![image-20230602001952707](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306020019615.png)

#### 打开多窗口

```java
import java.awt.*;
public class TestFrame2 {
    public static void main(String[] args) {
        new MyFrame(100,100,300,200,Color.red);
        new MyFrame(100,300,300,200,Color.blue);
        new MyFrame(400,100,300,200,Color.green);
        new MyFrame(400,300,300,200,Color.yellow);
    }
}

// 封装弹窗
class MyFrame extends Frame{
    static int id=0;// 窗口计数器 因为可能存在多个窗口 每弹出一个加1

    /**
     *
     * @param x
     * @param y
     * @param w  宽度
     * @param h  高度
     * @param color 背景色
     */
    public MyFrame(int x,int y,int w,int h,Color color){
        // 调用Frame构造方法 设置窗口title 每次弹出一个窗口id+1
        super("第 "+(++id)+" 个窗口");
        // 设置窗口可见性  由于直接继承了Frame 因此可以直接使用父类中的公共方法
        setVisible(true);
        // 设置窗口大小
        setBounds(x,y,w,h);
        // 设置窗口背景色
        setBackground(color);
        // 设置固定大小
        setResizable(false);
    }
}
```

![image-20230602003855254](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306020038551.png)

### 面板弹窗

```
面板(Panel) 可以看成一个空间 但是不能单独存在 需要配合Frame使用
```



```java

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// Panel弹窗
// Panel不能单独使用 需要放到Frame中
public class TestPanel {
    public static void main(String[] args) {
        // 创建Frame
        Frame frame = new Frame();
        // 布局
        Panel panel = new Panel();
        // 设置弹窗布局
        frame.setLayout(null);
        // 设置坐标
        frame.setBounds(300,300,500,500);
        // 设置背景色
        frame.setBackground(new Color(86, 183, 55));
        // 设置Panel坐标 是相对于frame窗体的坐标
        panel.setBounds(50,50,400,400);
        // 设置panel的背景色
        panel.setBackground(new Color(166, 64, 51));
        // 弹窗中添加panel布局
        frame.add(panel);
        // 设置窗体可见
        frame.setVisible(true);
        // 设置窗口固定大小
        frame.setResizable(false);
        // 窗口关闭事件
        // WindowAdapter是WindowListener实现类 因此可以直接拿来使用
        // 如果不使用其实现类则需要重写所有的创建监听事件
        // 这种模式被称之为适配器模式
        frame.addWindowListener(new WindowAdapter() {
            // 窗口关闭时要做的事情
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);// 正常退出程序
            }
        });
    }
}

```

![image-20230602072421826](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306020724579.png)

#### 布局

##### 流式布局(默认)

可以通过FlowLayout进行布局限制 例如按钮居中，居左或居右等

```java

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 流式布局
public class TestFlowLayout {

    public static void main(String[] args) {
        // 定义窗体
        Frame frame = new Frame();
        // 定义按钮组件
        Button btn1 = new Button("button1");
        Button btn2 = new Button("button1");
        Button btn3 = new Button("button1");

        // 设置为流式布局
        //frame.setLayout(new FlowLayout());
        frame.setLayout(new FlowLayout(FlowLayout.LEFT));// 居左

        // 给窗体添加按钮
        frame.add(btn1);
        frame.add(btn2);
        frame.add(btn3);

        // 设置窗体背景色
        frame.setBackground(new Color(78, 210, 38));
        // 设置窗体大小
        //frame.setSize(200,200);
        frame.setBounds(200,200,300,300);
        // 设置窗体可见
        frame.setVisible(true);


        // 关闭窗口事件
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);// 结束程序
            }
        });
    }

}

```

![image-20230602075131231](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306020751392.png)

##### 表格布局

```java

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 表格布局
public class TestGridLayout {

    public static void main(String[] args) {
        // 创建窗体
        Frame frame = new Frame();
        // 创建按钮 测试表格布局
        Button btn1 = new Button("btn1");
        Button btn2 = new Button("btn2");
        Button btn3 = new Button("btn3");
        Button btn4 = new Button("btn4");
        Button btn5 = new Button("btn5");
        Button btn6 = new Button("btn6");
        // 给按钮添加背景色
        btn1.setBackground(new Color(78, 210, 38));
        btn3.setBackground(new Color(38, 210, 164));
        btn5.setBackground(new Color(78, 210, 38));
        btn2.setBackground(new Color(38, 210, 164));
        btn4.setBackground(new Color(78, 210, 38));
        btn6.setBackground(new Color(38, 210, 164));
        // 将按钮添加到表格中
        frame.setLayout( new GridLayout(3,2));// 3行2列的表格
        // 将表格添加到窗体中
        frame.add(btn1);
        frame.add(btn2);
        frame.add(btn3);
        frame.add(btn4);
        frame.add(btn5);
        frame.add(btn6);

        // 设置自动布局
        frame.pack();
        // 设置窗体的打开位置
        frame.setBounds(200,200,300,300);

        // 设置窗体可见
        frame.setVisible(true);

        // 设置可关闭
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}

```

![image-20230602100436939](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230602100436939.png)

##### 东南西北中布局

通常作为整体界面的布局 例如上边是导航栏 左边是菜单栏 下边是版本信息 中间是内容区域

```java

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 东南西北中布局方式
public class TestBorderLayout {

    public static void main(String[] args) {
        // 创建窗体
        Frame frame = new Frame();
        // 创建按钮组件
        Button east = new Button("East");// 东
        Button west = new Button("West");// 西
        Button south = new Button("South");// 南
        Button north = new Button("North");// 北
        Button center = new Button("Center");// 中
        // 将按钮添加到窗体中
        frame.add(east,BorderLayout.EAST);
        frame.add(west,BorderLayout.WEST);
        frame.add(south,BorderLayout.SOUTH);
        frame.add(north,BorderLayout.NORTH);
        frame.add(center,BorderLayout.CENTER);

        // 设置窗体固定大小
        frame.setResizable(false);
        // 设置窗体背景色
        frame.setBackground(new Color(78, 210, 38));
        // 设置窗体可见
        frame.setVisible(true);
        // 设置窗体大小及弹窗位置
        frame.setBounds(200,200,300,300);
        // 设置可关闭
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}

```

![image-20230602094840471](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306021006251.png)



##### 作业练习

实现如下效果

![image-20230602101011528](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306021010876.png)

```java
思路：
   frame中使用面板嵌套表格
   分析：
      左右布局 中间为嵌套面板
    	左边 button
    	中间 面板
    	右边 button
    
```

```java

import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 复杂布局作业
public class TestLayout {

    public static void main(String[] args) {
        // 创建总窗体
        Frame frame = new Frame("布局作业");
        // 设置总窗体的布局 - 表格布局
        frame.setLayout(new GridLayout(2,1));

        
        // 定义上边两个面板
        Panel p1 = new Panel(new BorderLayout());
        // 中间面板
        Panel p2 = new Panel(new GridLayout(2,1));
        // 添加到表格布局
        p1.add(new Button("East-1"), BorderLayout.EAST);// 左边
        p1.add(new Button("West-1"), BorderLayout.WEST);// 右边
        p2.add(new Button("p2-btn-1"));// 中间的上边
        p2.add(new Button("p2-btn-2"));// 中间的下边
        // 把p2面板添加到p1中 放在中间位置
        p1.add(p2,BorderLayout.CENTER);
        // 定义下边两个面板
        Panel p3 = new Panel(new BorderLayout());
        // 中间面板
        Panel p4 = new Panel(new GridLayout(2,2));
        p3.add(new Button("East-2"), BorderLayout.EAST);// 左边
        p3.add(new Button("West-2"), BorderLayout.WEST);// 右边
        // 中间的4个面板
        for (int i = 0; i < 4; i++) {
            p4.add(new Button("p3-btn-"+i));
        }
        // 把p4面板添加到p3中
        p3.add(p4,BorderLayout.CENTER);

        /*
            将面板添加到frame中
            p2面板放到p1中，p4放到p3中 因此只需要添加两个面板到frame中即可
         */
        frame.add(p1);
        frame.add(p3);
        // 设置窗体可见
        frame.setVisible(true);
        // 设置背景色
        frame.setBackground(Color.BLACK);
        // 设置总窗体大小
        frame.setSize(600,400);
        // 设置弹出位置
        frame.setLocation(300,200);
        // 窗体可关闭
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}

```

![image-20230602111523430](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306021115968.png)

##### 作业2

![image-20230602143513413](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230602143513413.png)

```java

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 作业2
public class TestWork2 {

    public static void main(String[] args) {
        Frame frame = new Frame();
        // 表格布局
        frame.setLayout(new GridLayout(3,1));
        Panel p1 = new Panel(new BorderLayout());
        Panel p2 = new Panel(new GridLayout(1,2));
        Panel p3 = new Panel(new BorderLayout());
        p2.add(new Button("East"),BorderLayout.EAST);
        p2.add(new Button("West"),BorderLayout.WEST);

        // 设置面板背景色
        p1.setBackground(Color.RED);
        p3.setBackground(Color.GREEN);


        // 将面板添加到窗体中
        frame.add(p1);
        frame.add(p2);
        frame.add(p3);
        // 设置窗体可见
        frame.setVisible(true);
        // 按钮自动布局
        frame.pack();
        // 窗体弹出位置
        frame.setBounds(300,200,600,400);
        // 设置窗体可关闭
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}
```



![image-20230602144501068](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230602144501068.png)

##### 布局小结：

```
Frame 是一个顶级窗口
	注意 不能嵌套
	
Panel 是面板 不能单独使用 需要添加到容器中 例如Frame

布局管理器
	1. 流式布局
	2. 表格布局
	3. 东西南北中布局
	
组件的大小、定位、背景色、可见性、监听
```

## 监听

### 按钮监听事件

点击按钮后触发的事件

```java
package com.etjava.gui.event;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * 按钮事件
 */
public class TestActionListenerEvent {

    public static void main(String[] args) {
        Frame frame  = new Frame("测试按钮事件");
        Button btn = new Button("Test");
        // 给button添加事件
        btn.addActionListener(new MyActionListenet());
        // 将按钮添加到frame窗体中 并居中显示
        frame.add(btn,BorderLayout.CENTER);
        // 设置窗体可见
        frame.setVisible(true);
        // 设置窗体固定大小
        frame.setResizable(false);
        // 设置窗体弹出位置及大小
        frame.setBounds(200,200,300,300);
        // 设置可关闭
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}

class MyActionListenet implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("按钮被点击了");
    }
}

```

### 多个按钮共用一个监听

按钮在点击时可以传递一些信息 通过ActionEvent获取

```java
package com.etjava.gui.event;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/*
多按钮共用一个监听事件
 */
public class TestActionListenerEvent2 {
    public static void main(String[] args) {
        Frame frame = new Frame("start-stop");
        Button start = new Button("start");
        Button stop = new Button("stop");
        // 点击按钮时传递的信息数据
        start.setActionCommand("start");
        stop.setActionCommand("stop");

        MyActionListener myActionListener = new MyActionListener();
        // 按钮添加事件
        start.addActionListener(myActionListener);
        stop.addActionListener(myActionListener);

        // 将按钮添加到frame中
        frame.add(start,BorderLayout.EAST);
        frame.add(stop,BorderLayout.WEST);
        // 自适应布局
        frame.pack();
        // 设置可见
        frame.setVisible(true);
        //
        frame.setBounds(200,200,300,300);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });



    }

}

class MyActionListener implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent e) {
        //System.out.println("按钮被点击了 ："+e.getActionCommand());
        if(e.getActionCommand().equals("start")){
            System.out.println("开始按钮被点击了");
        }else if(e.getActionCommand().equals("stop")){
            System.out.println("停止按钮被点击了");
        }
    }
}
```

![image-20230604220742165](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306042207688.png)



### 文本框监听事件

#### 单行文本框

分层开发

主方法只负责启动程序   监听为单独的类，文本框组件另个单独的类

按下回车间时会自动触发ActionListener事件

```java
package com.etjava.gui.event;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 文本输入框
public class TestText01 {
    public static void main(String[] args) {
       new App();
    }
}

class App{
    public App(){
        Frame frame = new Frame("测试文本框");
        // 单行文本框
        TextField textField = new TextField();
        MyActionListener2 myActionListener2 = new MyActionListener2();

        // 设置替换文本 - 例如密码框输入的文字显示* 不影响后台正常接收数据
        textField.setEchoChar('*');

        // 设置文本框大小
        textField.setSize(300,350);
        
        textField.setBackground(new Color(231, 228, 228));
        // 监听文本框中输入的内容 - 按下回车键就会触发该监听事件
        textField.addActionListener(myActionListener2);
        // 将文本框放到frame中
        frame.add(textField,BorderLayout.NORTH);
        // 设置弹出窗口位置
        frame.setBounds(200,200,300,300);
        // 设置可见性
        frame.setVisible(true);
        // 设置固定大小
        frame.setResizable(false);
        // 可关闭
        close(frame);
    }
    public static void close(Frame frame){
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}

class MyActionListener2 implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent e) {
        // 获取资源
        TextField source = (TextField) e.getSource();
        // 获取输入框文本
        System.out.println(source.getText());
        // 每次回车后清空文本框
        source.setText("");
    }
}

```

##### 简易计算器

```java
package com.etjava.gui.event;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 简单的计算器
public class TestCalc {
    public static void main(String[] args) {
        new Calculator();
    }
}
// 计算器类
class Calculator extends Frame{
    public Calculator(){
        super("Simple Calculator");
        // 3个文本框
        TextField num1 = new TextField(10);
        TextField num2 = new TextField(10);
        TextField res = new TextField(20);


        // 一个按钮
        Button button = new Button("=");
        // 添加监听事件 当点击时需要进行运算
        CalcListener calcListener = new CalcListener(num1,num2,res);
        button.addActionListener(calcListener);
        // 一个标签 用来放运算符
        Label label = new Label("+");
        // 流式布局
        setLayout(new FlowLayout());
        // 添加到frame窗口中
        add(num1);
        add(label);
        add(num2);
        add(button);
        add(res);
        pack();// 自适应
        setVisible(true);
        // 设置弹出位置
        setLocation(300,400);
        // 固定大小
        setResizable(false);
        // 可关闭
        close(this);
    }
    private static void close(Frame frame){
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}

// 监听类
class CalcListener implements ActionListener {
    // 封装三个文本框的值
    private TextField num1, num2, res;

    public CalcListener(TextField num1, TextField num2, TextField res) {
        this.num1 = num1;
        this.num2 = num2;
        this.res = res;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // 获取加数和被加数
        String num1Text = num1.getText();
        if(num1Text==null){
            num1Text="0";
        }
        int a = Integer.parseInt(num1Text);

        String num2Text = num2.getText();
        if(num2Text==null){
            num2Text="0";
        }
        int b = Integer.parseInt(num2Text);

        // 点击按钮时进行加法运算
        res.setText((a+b)+"");
        // 清空前两个框
        num1.setText("");
        num2.setText("");
    }
}

```

![image-20230605102135003](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306051021410.png)

##### 计算器代码优化

```
充分理解 is a 和 have a 的关系
继承是is a 的关系
包含是have a 的关系
```

```java
package com.etjava.gui.event;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 简单的计算器
public class TestCalc2 {
    public static void main(String[] args) {
        new Calculator();
    }
}
// 计算器类
class Calculator2 extends Frame{// is a
    TextField num1,num2,res; // have a
    public Calculator2(){
        super("Simple Calculator");
        // 3个文本框
        num1 = new TextField(10);
        num2 = new TextField(10);
        res = new TextField(20);


        // 一个按钮
        Button button = new Button("=");
        // 添加监听事件 当点击时需要进行运算
        CalcListener2 calcListener = new CalcListener2(this);
        button.addActionListener(calcListener);
        // 一个标签 用来放运算符
        Label label = new Label("+");
        // 流式布局
        setLayout(new FlowLayout());
        // 添加到frame窗口中
        add(num1);
        add(label);
        add(num2);
        add(button);
        add(res);
        pack();// 自适应
        setVisible(true);
        // 设置弹出位置
        setLocation(300,400);
        // 固定大小
        setResizable(false);
        // 可关闭
        close(this);
    }
    private static void close(Frame frame){
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}

// 监听类
class CalcListener2 implements ActionListener {
    // 封装三个文本框的值
    private Calculator2 calculator2;// have a

    public CalcListener2(Calculator2 calculator2) {
        this.calculator2 = calculator2;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // 获取加数和被加数
        String num1Text = calculator2.num1.getText();
        if(num1Text==null){
            num1Text="0";
        }
        int a = Integer.parseInt(num1Text);

        String num2Text = calculator2.num2.getText();
        if(num2Text==null){
            num2Text="0";
        }
        int b = Integer.parseInt(num2Text);

        // 点击按钮时进行加法运算
        calculator2.res.setText((a+b)+"");
        // 清空前两个框
        calculator2.num1.setText("");
        calculator2.num2.setText("");
    }
}

```

## 画笔

### 画笔的基本使用

静态的 直接在窗体中画固定图形

```java
package com.etjava.gui.paint;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 画笔
// 可以在面板或窗体中画图
public class TestPaint {
    public static void main(String[] args) {
        new MyPaint();
    }

}

class MyPaint extends Frame{
    public MyPaint(){
        setVisible(true);
        setBounds(200,200,600,400);
    }

    // 画笔
    @Override
    public void paint(Graphics g){
        // 设置画笔颜色
        g.setColor(Color.RED);
        // 画圆 - 空心
        g.drawOval(100,100,100,100);
        // 实心圆
        g.fillOval(200,200,100,100);
        // 矩形
        g.setColor(Color.GREEN);
        g.fillRect(250,200,100,100);



        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }

}

```

![image-20230605111454059](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306051114461.png)

### 鼠标事件配合使用

#### 鼠标监听

##### 鼠标点击

```java
package com.etjava.gui.mouse;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class TestMouseListener  {
    public static void main(String[] args) {
        new MyFrame2();
    }

}

class MyFrame2 extends Frame{
    public MyFrame2()  {
        setBounds(200,200,300,300);
        setVisible(true);
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                System.out.println(e.getX()+"--"+e.getY());
            }
        });
    }

    @Override
    public void paint(Graphics g){
        // 设置画笔颜色
        g.setColor(Color.RED);
        // 画圆 - 空心
        g.drawOval(100,100,100,100);
    }
}

```

![image-20230608110525424](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306081105286.png)

##### 实现使用鼠标画画

```
思路
	首先需要一个画板（Frame） 还需要一个画笔 用来画画的
	还需要一个集合 用来保存鼠标每次点击后的坐标位置 需要在对应的坐标上画点
	需要监听鼠标按压事件 并保存鼠标按下时的坐标 并设置鼠标每次点击都重新画一次(刷新一次) repaint()
	画笔要读取鼠标每次点击时的坐标点 鼠标每次刷新都会调用一次画笔
	
```

![image-20230608111829921](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306081118559.png)

```java
package com.etjava.gui.mouse;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Iterator;

// 鼠标监听事件
public class MouseListener {
    public static void main(String[] args) {
        new MyFrame("msapint");
    }
}

class MyFrame extends Frame {

    // 画画需要画笔，还需要监听鼠标当前的位置 还需要集合存储当前鼠标点击的点是在那个位置
    ArrayList points;
    public MyFrame(String title){
        super(title);// frame弹窗标题
        // 存放鼠标点击的点
        points = new ArrayList<>();
        // 弹窗打开位置
        setBounds(200,200,400,300);
        // 设置弹窗显示
        setVisible(true);
        // 添加鼠标监听 - 针对这个窗口
        this.addMouseListener(new MyMouseListener());
    }



    // 重写画笔方法
    @Override
    public void paint(Graphics g) {

        // 监听鼠标的事件
        Iterator car = points.iterator();
        while(car.hasNext()){
            // 取到当前要画的点的坐标
            Point point = (Point) car.next();
            // 设置点的颜色
            g.setColor(Color.RED);
            // 这个点应该是个圆形 并且画在当前点击的位置 10 表示点的大小
            g.fillOval(point.x,point.y,10,10);
        }
    }
    // 添加一个点到界面上
//    public void addPaint(Point point){
//        points.add(point);// 保存鼠标点击的点
//    }

    // 鼠标监听 - 适配器模式
    private class MyMouseListener extends MouseAdapter{
        // 鼠标点击 - 按下，弹起，按住不放
        @Override
        public void mousePressed(MouseEvent e) {
            // 获取点击对象 - 谁调用鼠标监听该对象就是谁 这类是Frame调用的
            MyFrame myFrame = (MyFrame) e.getSource();
            // 当鼠标点击时 就在对应位置画一个点
            // Point这个点就是鼠标点击的坐标的点
//            myFrame.addPaint(new Point(e.getX(),e.getY()));
            // 保存鼠标点击的点
            points.add(new Point(e.getX(),e.getY()));
            // 每次点击鼠标都重新画一次
            myFrame.repaint();
        }
    }
}


```

![image-20230608144609828](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306081448887.png)

### 窗口监听

```java
package com.etjava.gui.window;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 窗口监听事件
public class TestWindowListener {
    public static void main(String[] args) {
        new MyFrame();
    }
}

class MyFrame extends Frame{
    public MyFrame(){
        super("窗口监听事件");
        setBounds(200,200,300,300);
        setResizable(false);
        setVisible(true);
        addWindowListener(new MyWindowListener());
    }

    class MyWindowListener extends WindowAdapter{

        // 窗口关闭事件
        @Override
        public void windowClosing(WindowEvent e) {
            System.out.println("窗口关闭中");
            // 正常退出
            System.exit(0);
        }
        @Override
        public void windowOpened(WindowEvent e) {
            System.out.println("窗口打开");
        }

        @Override
        public void windowClosed(WindowEvent e) {
            System.out.println("窗口已关闭");
        }

        @Override
        public void windowIconified(WindowEvent e) {
            System.out.println("窗口打开");
        }

        @Override
        public void windowActivated(WindowEvent e) {
            System.out.println("窗口被激活");
            MyFrame frame = (MyFrame) e.getSource();
            frame.setTitle("窗口被激活了");
        }
    }
}		
```

### 键盘监听事件

```
package com.etjava.gui.keybord;

import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

// 键盘监听事件
public class TestKeyBord {
    public static void main(String[] args) {
        new KeyFrame();
    }
}

class KeyFrame extends Frame{
    public KeyFrame(){
        setBounds(200,200,300,400);
        setVisible(true);
        setBackground(Color.GREEN);
        addKeyListener(new KeyAdapter() {
            // 按下事件
            @Override
            public void keyPressed(KeyEvent e) {
                int keyCode = e.getKeyCode();
                if(keyCode==KeyEvent.VK_UP){
                    System.out.println("按下了向上箭头按键");
                }
                 // 获取键盘输入的字符
//                char c = e.getKeyChar();
//                System.out.print(c);
            }
            // 释放事件
            @Override
            public void keyReleased(KeyEvent e) {
               // System.out.println("释放按键");
            }
        });
    }
}

```

## SWING

### JFrame

#### 弹窗

```
import javax.swing.*;
import java.awt.*;

// JFrame窗口
public class TestJFrame {
    public static void main(String[] args) {
        JFrame frame = new JFrame("JFrame");
        frame.setBackground(Color.RED);// 这里需要设置容器的背景色 非窗体的
        frame.setBounds(300,300,200,200);
        frame.setVisible(true);
        // 设置窗口关闭
        /*
        DO_NOTHING_ON_CLOSE = 0 点击后什么都不做
        HIDE_ON_CLOSE = 1 隐藏窗口 程序不会退出
        DISPOSE_ON_CLOSE = 2 隐藏窗口 当jvm运行完成后才会退出
        EXIT_ON_CLOSE = 3 关闭并退出程序
         */
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        
    }
}
```

### JLabel标签居中

```java
class MyJFrame extends JFrame{
    public MyJFrame(){
        Container container = getContentPane();
        container.setBackground(Color.GREEN);
        this.setBounds(600,600,400,400);
        this.setVisible(true);
        JLabel label = new JLabel("测试JFrame窗体");
        // 标签居中
        /*
        0 水平居中
        1 TOP
        2 LEFT
        3 BOTTOM
        4 RIGHT
        5 NORTH
        6 SOUTH_WEST
        7 WEST
        ...
         */
        label.setHorizontalAlignment(SwingConstants.CENTER);// 水平居中
        add(label);
        setDefaultCloseOperation(3);// 关闭并退出
    }
}
```

![image-20230616230457101](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306162305205.png)

#### 弹窗 - 子窗口

```java
package com.etjava.gui.swing.Dialog;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// 弹窗
public class MyFrame extends JFrame{
    public MyFrame(String title){
        setBounds(300,300,400,200);
        setDefaultCloseOperation(3);
        Container container = getContentPane();
        //container.setLayout(null);
        JLabel jLabel = new JLabel("第一个JFrame窗口");
        jLabel.setHorizontalAlignment(SwingConstants.CENTER);
        container.add(jLabel);
        setVisible(true);
        JButton button = new JButton("弹出对话框");
        button.setBounds(0,0,100,30);
        button.setVisible(true);
        add(button);
        button.addActionListener(new ActionListener() {     //添加按钮鼠标点击事件
            public void actionPerformed(ActionEvent e) {
                new MyJDialog(MyFrame.this).setVisible(true);
            }
        });
    }
    public static void main(String[] args) {
        new MyFrame("测试弹窗");
    }
}

// 子窗口
class MyJDialog extends JDialog {
    public MyJDialog(MyFrame frame){
        super(frame,"这是第一个JDialog窗口",true);
        Container container = getContentPane();
        setBounds(450,450,400,400);
        JLabel jLabel = new JLabel("这是一个JDialog窗口");
        container.add(jLabel);
    }
}

```

![image-20230616235513310](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306162355896.png)

### 标签

#### 创建标签

```java
new JLabel("用户名：");
```

#### 图标

Label中可以添加图标 图标可以是自定义的图片 也可以是基础形状等

```java
package com.etjava.gui.swing.label;

import javax.swing.*;
import java.awt.*;

// 标签
// 要使用图标 必须实现Icon接口
public class TestJLabel extends  JFrame implements Icon{
    private int w;// 图标的宽
    private int h;// 图标的高
    public TestJLabel(){}
    public TestJLabel(int w,int h){
        this.w = w;
        this.h = h;
    }
    public static void main(String[] args) {
        new TestJLabel().init();
    }

    public void init(){
        TestJLabel icon = new TestJLabel(15, 15);
        // 图标可以放在标签上，也可以放在按钮上等
        // 参数1 标签显示的文本，参数2 图标，参数3 标签中图标的位置
        JLabel label = new JLabel("userName:", icon, SwingConstants.CENTER);
        Container container = getContentPane();
        container.add(label);// 添加到容器中

        setVisible(true);
        setBounds(300,300,400,400);
        setDefaultCloseOperation(3);

    }

    // 画图标
    /*
    Component c,  图标存放的位置
    Graphics g,   画笔
    int x,      图标的坐标
    int y

     */
    @Override
    public void paintIcon(Component c, Graphics g, int x, int y) {
        // 画一个圆  w h 图标的宽度和高度
        g.drawOval(x,y,w,h);
    }

    // 获取图标的宽度
    @Override
    public int getIconWidth() {
        return this.w;
    }
    // 获取图标的高度
    @Override
    public int getIconHeight() {
        return this.h;
    }
}

```

![image-20230617150103234](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306171501415.png)

图标使用图片替代

```java
import javax.swing.*;
import java.awt.*;
import java.net.URL;

// 标签中使用图片
public class TesIcon extends  JFrame{

    public TesIcon(){
        // 读取图片
        URL url = TesIcon.class.getResource("1.jpeg");
        // 把图片放到ImageIcon组件中
        ImageIcon imageIcon = new ImageIcon(url);
        // 图标可以放在标签上，也可以放在按钮上等
        // 参数1 标签显示的文本，参数2 图标，参数3 标签中图标的位置
        JLabel label = new JLabel("userName:");
        // 添加图片到label
        label.setIcon(imageIcon);
        // 居中显示
        label.setHorizontalAlignment(SwingConstants.CENTER);

        // 窗体中的所有组件必须放到容器中才能显示
        Container container = getContentPane();
        container.add(label);// 添加到容器中

        setVisible(true);
        setBounds(300,300,400,400);
        setDefaultCloseOperation(3);
    }
    public static void main(String[] args) {
        new TesIcon();
    }

}

```

![image-20230617151846719](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306171518134.png)

### 面板

面板布局

```java
package com.etjava.gui.swing.jpanel;

import javax.swing.*;
import java.awt.*;

// 面板
public class TestJpanel extends JFrame {
    public TestJpanel(){
        Container container = getContentPane();
        // 后边的两个10 多个面板之间的间距
        container.setLayout(new GridLayout(2,1,10,10));
        // 创建面板
        JPanel panel1 = new JPanel(new GridLayout(1,3));
        JPanel panel2 = new JPanel(new GridLayout(1,2));
        JPanel panel3 = new JPanel(new GridLayout(2,1));
        JPanel panel4 = new JPanel(new GridLayout(3,2));
        panel1.add(new JButton("panel - 1"));
        panel1.add(new JButton("panel - 1"));
        panel1.add(new JButton("panel - 1"));
        panel2.add(new JButton("panel - 2"));
        panel2.add(new JButton("panel - 2"));
        panel3.add(new JButton("panel - 3"));
        panel3.add(new JButton("panel - 3"));
        panel4.add(new JButton("panel - 4"));
        panel4.add(new JButton("panel - 4"));
        panel4.add(new JButton("panel - 4"));
        panel4.add(new JButton("panel - 4"));
        panel4.add(new JButton("panel - 4"));
        panel4.add(new JButton("panel - 4"));

        // 添加到面板
        container.add(panel1);
        container.add(panel2);
        container.add(panel3);
        container.add(panel4);
        // 弹窗显示
        setVisible(true);
        setBounds(300,300,600,400);
        setDefaultCloseOperation(3);
    }

    public static void main(String[] args) {
        new TestJpanel();
    }
}

```

![image-20230617153209932](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306171532151.png)

#### JScrollPanel

面板滚动条

```java
package com.etjava.gui.swing.jpanel;

import javax.swing.*;
import java.awt.*;

// 测试滚动条
public class TestJScrollPanel extends JFrame {

    public TestJScrollPanel(){
        Container container = getContentPane();
        // 文本域
        JTextArea textArea = new JTextArea(20, 50);
        // 可设置默认文字
        textArea.setText("hello world");
        // 将文本域放到面板中 - 不能直接放到容器 
        JScrollPane scrollPane = new JScrollPane(textArea);
        container.add(scrollPane);


        setBounds(300,300,500,150);
        setVisible(true);
        setDefaultCloseOperation(3);

    }

    public static void main(String[] args) {
        new TestJScrollPanel();
    }
}

```

![image-20230617153922741](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306171539604.png)



### 按钮

单选，多选



### 下拉框











































































































































































































