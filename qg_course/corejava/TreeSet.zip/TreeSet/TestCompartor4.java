/*
	�����ڲ���ʵ��Comparator�ӿ�
	�ڴ���TreeSetʱ ���췽����ֱ�Ӵ���Comparator�ӿڲ�����ʵ��
*/
import java.util.*;
public class TestCompartor4{
	public static void main(String[] args){
		TreeSet<Student2> set = new TreeSet<>(new Comparator<Student2>(){
			@Override
			public int compare(Student2 s1,Student2 s2){
				System.out.println("------Comparator-------");
				return s1.score - s2.score;
			}
		});
		set.add(new Student2("Tom",18,90));
		set.add(new Student2("Jerry",19,80));
		set.add(new Student2("Andy",16,90));
		System.out.println(set);
	}
}
class Student2 implements Comparable<Student2>{
	String name;
	int age;
	int score;
	public Student2(String name,int age,int score){
		this.name = name;
		this.age = age;
		this.score = score;
	}
	@Override
	public int compareTo(Student2 stu){
		System.out.println("------Comparable-------");
		return this.age - stu.age;
	}
	@Override
	public String toString(){
		return "{"+name+" , "+age+" , "+score+"}";
	}
}