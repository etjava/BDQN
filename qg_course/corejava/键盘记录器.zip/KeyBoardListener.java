import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

public class KeyBoardListener extends JFrame {

    /**
     *
     */
    private static final long serialVersionUID = 7158985419563418289L;
    private JPanel contentPane;
    private JTextField textField;
    private JPasswordField passwordField;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Throwable e) {
            e.printStackTrace();
        }
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    KeyBoardListener frame = new KeyBoardListener();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public KeyBoardListener() {
        setTitle("\u952E\u76D8\u8BB0\u5F55\u5668");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 250, 160);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(new GridLayout(3, 1, 5, 5));

        JPanel panel1 = new JPanel();
        contentPane.add(panel1);

        JLabel label1 = new JLabel("\u7528\u6237\u540D\uFF1A");
        panel1.add(label1);

        textField = new JTextField();
        panel1.add(textField);
        textField.setColumns(10);

        JPanel panel2 = new JPanel();
        contentPane.add(panel2);

        JLabel label2 = new JLabel("\u5BC6    \u7801\uFF1A");
        panel2.add(label2);

        passwordField = new JPasswordField();
        passwordField.setColumns(10);
        panel2.add(passwordField);

        JPanel panel3 = new JPanel();
        contentPane.add(panel3);

        JButton button = new JButton("\u767B\u5F55");
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                do_button_actionPerformed(e);
            }
        });
        panel3.add(button);
    }

    protected void do_button_actionPerformed(ActionEvent e) {
        String username = textField.getText();// ����û���
        String password = new String(passwordField.getPassword());// �������
        if ((username.isEmpty()) || (password.isEmpty())) {// �ж��û����������Ƿ�Ϊ��
            JOptionPane.showMessageDialog(this, "�û���������Ϊ�գ�", null, JOptionPane.WARNING_MESSAGE);
            return;
        }
        File file = new File("d:/account.txt");// �����ļ������˺���Ϣ
        String content = "�û�����" + username + " ���룺" + password;// ���Ҫд����ַ���
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(file);// �����ļ����������
            fos.write(content.getBytes());// ���ַ���д�뵽�ļ���
        } catch (FileNotFoundException e1) {
            e1.printStackTrace();
        } catch (IOException e1) {
            e1.printStackTrace();
        } finally {
            try {
                fos.close();// �ر��ļ������
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }

    }
}
