import java.util.*;

/*
	����������Ͷ���
	1. key��ͬ value������
	2. HashMap �϶�Ψһ
			1st && (2nd || 3th)
			1st. hashCode  2nd. == 3th. equals
*/
public class TestHashMap2{
	public static void main(String[] args){
		/*
		HashMap<String,Object> map = new HashMap<>();
		map.put("name1","Tom");
		map.put("name2","Jerry");
		map.put("name1","Andy");
		System.out.println(map);
		*/

		HashMap<Student,Object> map = new HashMap<>();
		Student s1 = new Student("Tom",12);
		Student s2 = new Student("Tom",12);
		map.put(s1,"stu1");
		map.put(s2,"stu2");
		System.out.println(map);
	}
}
class Student{
	String name;
	int age;
	public Student(String name,int age){
		this.name = name;
		this.age = age;
	}

	@Override
	public int hashCode(){
		return name.hashCode()+age;
	}

	@Override
	public boolean equals(Object o){
		Student s1 = this;
		Student s2 = (Student) o;
		return s1.name.equals(s1.name) && s1.age == s2.age;
	}

	@Override
	public String toString(){
		return "{"+name+"="+age+"}";
	}
}