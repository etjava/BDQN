import java.util.*;
public class TestHashtable2{
	/*
		�����������Ͷ���
	*/
	public static void main(String[] args){
		Hashtable<Student,Object> table  = new Hashtable<>();
		Student stu1 = new Student("Tom",12);
		Student stu2 = new Student("Tom",12);
		table.put(stu1,1001);
		table.put(stu2,1002);
		// ��֤�Ƿ�����ӿ�ֵ
		//table.put(null,1003);
		//table.put(stu1,null);
		//table.put(null,null);
		System.out.println(table);
	}
}

class Student{
	String name;
	int age;
	public Student(String name,int age){
		this.name = name;
		this.age = age;
	}

	@Override
	public int hashCode(){
		return name.hashCode()+age;
	}

	@Override
	public boolean equals(Object o){
		Student s1 = this;
		Student s2 = (Student) o;
		return s1.name.equals(s2.name) && s1.age == s2.age;
	}


	@Override
	public String toString(){
		return "{"+"name="+name+", age="+age+"}";
	}
}