Data 接口 封装通用字体
Chart 方格及里面的数字
Game2048 游戏主体
Form 组合窗体并启动程序