import java.util.*;

/*
	Hashtable�����÷�
*/
public class TestHashtable1{
	public static void main(String[] args){
		// �����Ķ���
		Hashtable<String,Object> table = new Hashtable<>();
		// ����Ԫ��
		table.put("name1","Tom");
		table.put("name2","Jerry");
		table.put("name3","Andy");
		table.put("name4","Haily");
		System.out.println(table);
		// ��ȡһ��Ԫ��
		Object name = table.get("name1");
		System.out.println(name);
		// ��ȡ���ϴ�С
		int num = table.size();
		System.out.println(num);
		// ɾ��ָ��Ԫ��
		table.remove("name1");
		System.out.println(table);
		System.out.println("==================");
		// ����
		// ��ȡȫ��key
		Set<String> set = table.keySet();
		for(String key:set){
			System.out.println("key="+key+", value="+table.get(key));
		}
		System.out.println("==================");
		// ��ȡȫ��value
		Collection<Object> values = table.values();
		for(Object o:values){
			System.out.println(o);
		}
		System.out.println("==================");
		// ��ȡk - v
		Set<Map.Entry<String,Object>> ens = table.entrySet();
		for(Map.Entry<String,Object> en:ens){
			System.out.println(en.getKey()+"--"+en.getValue());
		}
		// ��ռ���
		table.clear();
		System.out.println(table);
	}
}