public class TestFor{

	public static void main(String[] args){

		// ����forѭ��
		for(int i=0;i<10;i++){// ++i  i++
			System.out.println("i = "+i);
		}
	}
}