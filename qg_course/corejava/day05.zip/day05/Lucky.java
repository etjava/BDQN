import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Lucky{
	JFrame frame;
	JButton bt;
	JTextField jtf;
	boolean isRunning;
	public Lucky(){
		frame = new JFrame("aaa");
		bt = new JButton("ddd");
		bt.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				isRunning = !isRunning;
				if(isRunning){
					new Thread(){
						public void run(){
							while(isRunning){
								jtf.setText((int)(Math.random()*25)+1+"");
							}
						}
					}.start();
				}
			}

		});
		jtf = new JTextField();
		jtf.setFont(new Font("宋体",1,64));
		frame.add(jtf,"North");
		frame.add(bt,"Center");
		frame.setSize(200,300);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(3);

		Toolkit kit = Toolkit.getDefaultToolkit();
		Dimension screenSize = kit.getScreenSize();
		int screenHeight = screenSize.height;
		int screenWidth = screenSize.width;
		frame.setBounds(screenWidth/4, screenHeight/4, screenWidth/2, screenHeight/2);
	}
	public static void main(String[] args){
		new Lucky();
	}
}