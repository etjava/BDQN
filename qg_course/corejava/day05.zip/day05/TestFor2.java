/*
	for循环嵌套
*/
public class TestFor2{
	public static void main(String[] args){
		// 计算 1+1,1+9,2+1 2+9 3+1 3+9 ...
		abc:for(int i=1;i<=9;i++){
			def:for(int j = 1;j<=9;j++){
				if(i==2){
					//continue;
					break abc;
				}
				System.out.println(i+"+"+j+"="+(i+j));
			}
		}
	}
}