
public class HelloWorld{
	static int RES=10;

	public static void main(String[] args){
		System.out.println("HelloWorld");

		int i = 10;
		int j = 9;
		System.out.println("res "+(i+j));

		Student stu = new Student();


		byte bit = 127;

	}
}

class Student{

}