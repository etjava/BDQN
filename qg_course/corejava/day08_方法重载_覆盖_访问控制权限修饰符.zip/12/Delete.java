import java.io.*;
public class Delete{
	public static void main(String[] args){
		File f = new File(".");
		File[] files = f.listFiles(new FilenameFilter(){
			public boolean accept(File dir,String name){
				return name.toLowerCase().endsWith(".class");
			}
		});

		for(File ff:files)
			ff.delete();
	}
}