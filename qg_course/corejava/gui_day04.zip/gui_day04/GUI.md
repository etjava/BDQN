# GUI

## 介绍

```
GUI是什么？
	GUI是图形用户界面编程
	GUI程序是带有图形界面的Java程序
怎么用？
	组件
	窗口、弹窗、面板、文本框、列表框、按钮、图片、监听事件、鼠标事件、键盘事件
用在什么地方？
	GUI可以做破解工具，外挂（只能检测到JVM 不会检测到实际的应用程序）等
怎么学？
	GUI的核心组件： Swing、ATW

扩展
	之所以现在使用GUI的比较少 其主要原因是页面不美观，需要JRE运行环境（玩一个5M的游戏需要下载安装几十M的环境）

我们为什么要学习？
	1. 可以写出自己心中想要的一些小工具
	2. 工作的时候也可能会维护到swing页面 概率极小
	3. 是MVC的基础 - 监听
	
```

## AWT

```
AWT - Abstract Window Tools 抽象的窗口工具
	包含了很多的类和窗口 例如 new Button 会出现一个按钮，new Fream 会出现一个弹窗等
	
```

 ![image-20230602000044907](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306020000452.png)

### Frame弹窗

#### 第一个窗口程序

```java
import java.awt.*;

// 第一个GUI程序
public class TestFrame {
    public static void main(String[] args) {
        // 定义窗体组件 Frame
        Frame frame = new Frame("第一个GUI程序");
        // 设置窗体的可见性 默认是内存中的 不可见的
        frame.setVisible(true);
        // 设置窗口大小
        frame.setSize(500,300);
        // 弹窗的初始位置 默认在左上角
        frame.setLocation(500,200);
        // 设置弹窗的背景颜色
        frame.setBackground(new Color(86, 183, 55));
        //frame.setBackground(Color.BLACK);
        // 设置窗口固定大小
        frame.setResizable(false);

    }
}

```

![image-20230602001952707](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306020019615.png)

#### 打开多窗口

```java
import java.awt.*;
public class TestFrame2 {
    public static void main(String[] args) {
        new MyFrame(100,100,300,200,Color.red);
        new MyFrame(100,300,300,200,Color.blue);
        new MyFrame(400,100,300,200,Color.green);
        new MyFrame(400,300,300,200,Color.yellow);
    }
}

// 封装弹窗
class MyFrame extends Frame{
    static int id=0;// 窗口计数器 因为可能存在多个窗口 每弹出一个加1

    /**
     *
     * @param x
     * @param y
     * @param w  宽度
     * @param h  高度
     * @param color 背景色
     */
    public MyFrame(int x,int y,int w,int h,Color color){
        // 调用Frame构造方法 设置窗口title 每次弹出一个窗口id+1
        super("第 "+(++id)+" 个窗口");
        // 设置窗口可见性  由于直接继承了Frame 因此可以直接使用父类中的公共方法
        setVisible(true);
        // 设置窗口大小
        setBounds(x,y,w,h);
        // 设置窗口背景色
        setBackground(color);
        // 设置固定大小
        setResizable(false);
    }
}
```

![image-20230602003855254](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306020038551.png)

### 面板弹窗

```
面板(Panel) 可以看成一个空间 但是不能单独存在 需要配合Frame使用
```



```java

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// Panel弹窗
// Panel不能单独使用 需要放到Frame中
public class TestPanel {
    public static void main(String[] args) {
        // 创建Frame
        Frame frame = new Frame();
        // 布局
        Panel panel = new Panel();
        // 设置弹窗布局
        frame.setLayout(null);
        // 设置坐标
        frame.setBounds(300,300,500,500);
        // 设置背景色
        frame.setBackground(new Color(86, 183, 55));
        // 设置Panel坐标 是相对于frame窗体的坐标
        panel.setBounds(50,50,400,400);
        // 设置panel的背景色
        panel.setBackground(new Color(166, 64, 51));
        // 弹窗中添加panel布局
        frame.add(panel);
        // 设置窗体可见
        frame.setVisible(true);
        // 设置窗口固定大小
        frame.setResizable(false);
        // 窗口关闭事件
        // WindowAdapter是WindowListener实现类 因此可以直接拿来使用
        // 如果不使用其实现类则需要重写所有的创建监听事件
        // 这种模式被称之为适配器模式
        frame.addWindowListener(new WindowAdapter() {
            // 窗口关闭时要做的事情
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);// 正常退出程序
            }
        });
    }
}

```

![image-20230602072421826](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306020724579.png)

#### 布局

##### 流式布局(默认)

可以通过FlowLayout进行布局限制 例如按钮居中，居左或居右等

```java

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 流式布局
public class TestFlowLayout {

    public static void main(String[] args) {
        // 定义窗体
        Frame frame = new Frame();
        // 定义按钮组件
        Button btn1 = new Button("button1");
        Button btn2 = new Button("button1");
        Button btn3 = new Button("button1");

        // 设置为流式布局
        //frame.setLayout(new FlowLayout());
        frame.setLayout(new FlowLayout(FlowLayout.LEFT));// 居左

        // 给窗体添加按钮
        frame.add(btn1);
        frame.add(btn2);
        frame.add(btn3);

        // 设置窗体背景色
        frame.setBackground(new Color(78, 210, 38));
        // 设置窗体大小
        //frame.setSize(200,200);
        frame.setBounds(200,200,300,300);
        // 设置窗体可见
        frame.setVisible(true);


        // 关闭窗口事件
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);// 结束程序
            }
        });
    }

}

```

![image-20230602075131231](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306020751392.png)

##### 表格布局

```java

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 表格布局
public class TestGridLayout {

    public static void main(String[] args) {
        // 创建窗体
        Frame frame = new Frame();
        // 创建按钮 测试表格布局
        Button btn1 = new Button("btn1");
        Button btn2 = new Button("btn2");
        Button btn3 = new Button("btn3");
        Button btn4 = new Button("btn4");
        Button btn5 = new Button("btn5");
        Button btn6 = new Button("btn6");
        // 给按钮添加背景色
        btn1.setBackground(new Color(78, 210, 38));
        btn3.setBackground(new Color(38, 210, 164));
        btn5.setBackground(new Color(78, 210, 38));
        btn2.setBackground(new Color(38, 210, 164));
        btn4.setBackground(new Color(78, 210, 38));
        btn6.setBackground(new Color(38, 210, 164));
        // 将按钮添加到表格中
        frame.setLayout( new GridLayout(3,2));// 3行2列的表格
        // 将表格添加到窗体中
        frame.add(btn1);
        frame.add(btn2);
        frame.add(btn3);
        frame.add(btn4);
        frame.add(btn5);
        frame.add(btn6);

        // 设置自动布局
        frame.pack();
        // 设置窗体的打开位置
        frame.setBounds(200,200,300,300);

        // 设置窗体可见
        frame.setVisible(true);

        // 设置可关闭
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}

```

![image-20230602100436939](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230602100436939.png)

##### 东南西北中布局

通常作为整体界面的布局 例如上边是导航栏 左边是菜单栏 下边是版本信息 中间是内容区域

```java

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 东南西北中布局方式
public class TestBorderLayout {

    public static void main(String[] args) {
        // 创建窗体
        Frame frame = new Frame();
        // 创建按钮组件
        Button east = new Button("East");// 东
        Button west = new Button("West");// 西
        Button south = new Button("South");// 南
        Button north = new Button("North");// 北
        Button center = new Button("Center");// 中
        // 将按钮添加到窗体中
        frame.add(east,BorderLayout.EAST);
        frame.add(west,BorderLayout.WEST);
        frame.add(south,BorderLayout.SOUTH);
        frame.add(north,BorderLayout.NORTH);
        frame.add(center,BorderLayout.CENTER);

        // 设置窗体固定大小
        frame.setResizable(false);
        // 设置窗体背景色
        frame.setBackground(new Color(78, 210, 38));
        // 设置窗体可见
        frame.setVisible(true);
        // 设置窗体大小及弹窗位置
        frame.setBounds(200,200,300,300);
        // 设置可关闭
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}

```

![image-20230602094840471](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306021006251.png)



##### 作业练习

实现如下效果

![image-20230602101011528](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306021010876.png)

```java
思路：
   frame中使用面板嵌套表格
   分析：
      左右布局 中间为嵌套面板
    	左边 button
    	中间 面板
    	右边 button
    
```

```java

import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 复杂布局作业
public class TestLayout {

    public static void main(String[] args) {
        // 创建总窗体
        Frame frame = new Frame("布局作业");
        // 设置总窗体的布局 - 表格布局
        frame.setLayout(new GridLayout(2,1));

        
        // 定义上边两个面板
        Panel p1 = new Panel(new BorderLayout());
        // 中间面板
        Panel p2 = new Panel(new GridLayout(2,1));
        // 添加到表格布局
        p1.add(new Button("East-1"), BorderLayout.EAST);// 左边
        p1.add(new Button("West-1"), BorderLayout.WEST);// 右边
        p2.add(new Button("p2-btn-1"));// 中间的上边
        p2.add(new Button("p2-btn-2"));// 中间的下边
        // 把p2面板添加到p1中 放在中间位置
        p1.add(p2,BorderLayout.CENTER);
        // 定义下边两个面板
        Panel p3 = new Panel(new BorderLayout());
        // 中间面板
        Panel p4 = new Panel(new GridLayout(2,2));
        p3.add(new Button("East-2"), BorderLayout.EAST);// 左边
        p3.add(new Button("West-2"), BorderLayout.WEST);// 右边
        // 中间的4个面板
        for (int i = 0; i < 4; i++) {
            p4.add(new Button("p3-btn-"+i));
        }
        // 把p4面板添加到p3中
        p3.add(p4,BorderLayout.CENTER);

        /*
            将面板添加到frame中
            p2面板放到p1中，p4放到p3中 因此只需要添加两个面板到frame中即可
         */
        frame.add(p1);
        frame.add(p3);
        // 设置窗体可见
        frame.setVisible(true);
        // 设置背景色
        frame.setBackground(Color.BLACK);
        // 设置总窗体大小
        frame.setSize(600,400);
        // 设置弹出位置
        frame.setLocation(300,200);
        // 窗体可关闭
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}

```

![image-20230602111523430](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306021115968.png)

##### 作业2

![image-20230602143513413](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230602143513413.png)

```java

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 作业2
public class TestWork2 {

    public static void main(String[] args) {
        Frame frame = new Frame();
        // 表格布局
        frame.setLayout(new GridLayout(3,1));
        Panel p1 = new Panel(new BorderLayout());
        Panel p2 = new Panel(new GridLayout(1,2));
        Panel p3 = new Panel(new BorderLayout());
        p2.add(new Button("East"),BorderLayout.EAST);
        p2.add(new Button("West"),BorderLayout.WEST);

        // 设置面板背景色
        p1.setBackground(Color.RED);
        p3.setBackground(Color.GREEN);


        // 将面板添加到窗体中
        frame.add(p1);
        frame.add(p2);
        frame.add(p3);
        // 设置窗体可见
        frame.setVisible(true);
        // 按钮自动布局
        frame.pack();
        // 窗体弹出位置
        frame.setBounds(300,200,600,400);
        // 设置窗体可关闭
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}
```



![image-20230602144501068](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230602144501068.png)

##### 布局小结：

```
Frame 是一个顶级窗口
	注意 不能嵌套
	
Panel 是面板 不能单独使用 需要添加到容器中 例如Frame

布局管理器
	1. 流式布局
	2. 表格布局
	3. 东西南北中布局
	
组件的大小、定位、背景色、可见性、监听
```

## 监听

### 按钮监听事件

点击按钮后触发的事件

```java
package com.etjava.gui.event;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * 按钮事件
 */
public class TestActionListenerEvent {

    public static void main(String[] args) {
        Frame frame  = new Frame("测试按钮事件");
        Button btn = new Button("Test");
        // 给button添加事件
        btn.addActionListener(new MyActionListenet());
        // 将按钮添加到frame窗体中 并居中显示
        frame.add(btn,BorderLayout.CENTER);
        // 设置窗体可见
        frame.setVisible(true);
        // 设置窗体固定大小
        frame.setResizable(false);
        // 设置窗体弹出位置及大小
        frame.setBounds(200,200,300,300);
        // 设置可关闭
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}

class MyActionListenet implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("按钮被点击了");
    }
}

```

### 多个按钮共用一个监听

按钮在点击时可以传递一些信息 通过ActionEvent获取

```java
package com.etjava.gui.event;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/*
多按钮共用一个监听事件
 */
public class TestActionListenerEvent2 {
    public static void main(String[] args) {
        Frame frame = new Frame("start-stop");
        Button start = new Button("start");
        Button stop = new Button("stop");
        // 点击按钮时传递的信息数据
        start.setActionCommand("start");
        stop.setActionCommand("stop");

        MyActionListener myActionListener = new MyActionListener();
        // 按钮添加事件
        start.addActionListener(myActionListener);
        stop.addActionListener(myActionListener);

        // 将按钮添加到frame中
        frame.add(start,BorderLayout.EAST);
        frame.add(stop,BorderLayout.WEST);
        // 自适应布局
        frame.pack();
        // 设置可见
        frame.setVisible(true);
        //
        frame.setBounds(200,200,300,300);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });



    }

}

class MyActionListener implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent e) {
        //System.out.println("按钮被点击了 ："+e.getActionCommand());
        if(e.getActionCommand().equals("start")){
            System.out.println("开始按钮被点击了");
        }else if(e.getActionCommand().equals("stop")){
            System.out.println("停止按钮被点击了");
        }
    }
}
```

![image-20230604220742165](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306042207688.png)



### 文本框监听事件

#### 单行文本框

分层开发

主方法只负责启动程序   监听为单独的类，文本框组件另个单独的类

按下回车间时会自动触发ActionListener事件

```java
package com.etjava.gui.event;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 文本输入框
public class TestText01 {
    public static void main(String[] args) {
       new App();
    }
}

class App{
    public App(){
        Frame frame = new Frame("测试文本框");
        // 单行文本框
        TextField textField = new TextField();
        MyActionListener2 myActionListener2 = new MyActionListener2();

        // 设置替换文本 - 例如密码框输入的文字显示* 不影响后台正常接收数据
        textField.setEchoChar('*');

        // 设置文本框大小
        textField.setSize(300,350);
        
        textField.setBackground(new Color(231, 228, 228));
        // 监听文本框中输入的内容 - 按下回车键就会触发该监听事件
        textField.addActionListener(myActionListener2);
        // 将文本框放到frame中
        frame.add(textField,BorderLayout.NORTH);
        // 设置弹出窗口位置
        frame.setBounds(200,200,300,300);
        // 设置可见性
        frame.setVisible(true);
        // 设置固定大小
        frame.setResizable(false);
        // 可关闭
        close(frame);
    }
    public static void close(Frame frame){
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}

class MyActionListener2 implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent e) {
        // 获取资源
        TextField source = (TextField) e.getSource();
        // 获取输入框文本
        System.out.println(source.getText());
        // 每次回车后清空文本框
        source.setText("");
    }
}

```

##### 简易计算器

```java
package com.etjava.gui.event;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 简单的计算器
public class TestCalc {
    public static void main(String[] args) {
        new Calculator();
    }
}
// 计算器类
class Calculator extends Frame{
    public Calculator(){
        super("Simple Calculator");
        // 3个文本框
        TextField num1 = new TextField(10);
        TextField num2 = new TextField(10);
        TextField res = new TextField(20);


        // 一个按钮
        Button button = new Button("=");
        // 添加监听事件 当点击时需要进行运算
        CalcListener calcListener = new CalcListener(num1,num2,res);
        button.addActionListener(calcListener);
        // 一个标签 用来放运算符
        Label label = new Label("+");
        // 流式布局
        setLayout(new FlowLayout());
        // 添加到frame窗口中
        add(num1);
        add(label);
        add(num2);
        add(button);
        add(res);
        pack();// 自适应
        setVisible(true);
        // 设置弹出位置
        setLocation(300,400);
        // 固定大小
        setResizable(false);
        // 可关闭
        close(this);
    }
    private static void close(Frame frame){
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}

// 监听类
class CalcListener implements ActionListener {
    // 封装三个文本框的值
    private TextField num1, num2, res;

    public CalcListener(TextField num1, TextField num2, TextField res) {
        this.num1 = num1;
        this.num2 = num2;
        this.res = res;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // 获取加数和被加数
        String num1Text = num1.getText();
        if(num1Text==null){
            num1Text="0";
        }
        int a = Integer.parseInt(num1Text);

        String num2Text = num2.getText();
        if(num2Text==null){
            num2Text="0";
        }
        int b = Integer.parseInt(num2Text);

        // 点击按钮时进行加法运算
        res.setText((a+b)+"");
        // 清空前两个框
        num1.setText("");
        num2.setText("");
    }
}

```

![image-20230605102135003](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306051021410.png)

##### 计算器代码优化

```
充分理解 is a 和 have a 的关系
继承是is a 的关系
包含是have a 的关系
```

```java
package com.etjava.gui.event;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 简单的计算器
public class TestCalc2 {
    public static void main(String[] args) {
        new Calculator();
    }
}
// 计算器类
class Calculator2 extends Frame{// is a
    TextField num1,num2,res; // have a
    public Calculator2(){
        super("Simple Calculator");
        // 3个文本框
        num1 = new TextField(10);
        num2 = new TextField(10);
        res = new TextField(20);


        // 一个按钮
        Button button = new Button("=");
        // 添加监听事件 当点击时需要进行运算
        CalcListener2 calcListener = new CalcListener2(this);
        button.addActionListener(calcListener);
        // 一个标签 用来放运算符
        Label label = new Label("+");
        // 流式布局
        setLayout(new FlowLayout());
        // 添加到frame窗口中
        add(num1);
        add(label);
        add(num2);
        add(button);
        add(res);
        pack();// 自适应
        setVisible(true);
        // 设置弹出位置
        setLocation(300,400);
        // 固定大小
        setResizable(false);
        // 可关闭
        close(this);
    }
    private static void close(Frame frame){
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}

// 监听类
class CalcListener2 implements ActionListener {
    // 封装三个文本框的值
    private Calculator2 calculator2;// have a

    public CalcListener2(Calculator2 calculator2) {
        this.calculator2 = calculator2;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // 获取加数和被加数
        String num1Text = calculator2.num1.getText();
        if(num1Text==null){
            num1Text="0";
        }
        int a = Integer.parseInt(num1Text);

        String num2Text = calculator2.num2.getText();
        if(num2Text==null){
            num2Text="0";
        }
        int b = Integer.parseInt(num2Text);

        // 点击按钮时进行加法运算
        calculator2.res.setText((a+b)+"");
        // 清空前两个框
        calculator2.num1.setText("");
        calculator2.num2.setText("");
    }
}

```

## 画笔

### 画笔的基本使用

静态的 直接在窗体中画固定图形

```java
package com.etjava.gui.paint;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 画笔
// 可以在面板或窗体中画图
public class TestPaint {
    public static void main(String[] args) {
        new MyPaint();
    }

}

class MyPaint extends Frame{
    public MyPaint(){
        setVisible(true);
        setBounds(200,200,600,400);
    }

    // 画笔
    @Override
    public void paint(Graphics g){
        // 设置画笔颜色
        g.setColor(Color.RED);
        // 画圆 - 空心
        g.drawOval(100,100,100,100);
        // 实心圆
        g.fillOval(200,200,100,100);
        // 矩形
        g.setColor(Color.GREEN);
        g.fillRect(250,200,100,100);



        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }

}

```

![image-20230605111454059](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306051114461.png)

### 鼠标事件配合使用

#### 鼠标监听

##### 鼠标点击

```java
package com.etjava.gui.mouse;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class TestMouseListener  {
    public static void main(String[] args) {
        new MyFrame2();
    }

}

class MyFrame2 extends Frame{
    public MyFrame2()  {
        setBounds(200,200,300,300);
        setVisible(true);
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                System.out.println(e.getX()+"--"+e.getY());
            }
        });
    }

    @Override
    public void paint(Graphics g){
        // 设置画笔颜色
        g.setColor(Color.RED);
        // 画圆 - 空心
        g.drawOval(100,100,100,100);
    }
}

```

![image-20230608110525424](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306081105286.png)

##### 实现使用鼠标画画

```
思路
	首先需要一个画板（Frame） 还需要一个画笔 用来画画的
	还需要一个集合 用来保存鼠标每次点击后的坐标位置 需要在对应的坐标上画点
	需要监听鼠标按压事件 并保存鼠标按下时的坐标 并设置鼠标每次点击都重新画一次(刷新一次) repaint()
	画笔要读取鼠标每次点击时的坐标点 鼠标每次刷新都会调用一次画笔
	
```

![image-20230608111829921](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306081118559.png)

```java
package com.etjava.gui.mouse;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Iterator;

// 鼠标监听事件
public class MouseListener {
    public static void main(String[] args) {
        new MyFrame("msapint");
    }
}

class MyFrame extends Frame {

    // 画画需要画笔，还需要监听鼠标当前的位置 还需要集合存储当前鼠标点击的点是在那个位置
    ArrayList points;
    public MyFrame(String title){
        super(title);// frame弹窗标题
        // 存放鼠标点击的点
        points = new ArrayList<>();
        // 弹窗打开位置
        setBounds(200,200,400,300);
        // 设置弹窗显示
        setVisible(true);
        // 添加鼠标监听 - 针对这个窗口
        this.addMouseListener(new MyMouseListener());
    }



    // 重写画笔方法
    @Override
    public void paint(Graphics g) {

        // 监听鼠标的事件
        Iterator car = points.iterator();
        while(car.hasNext()){
            // 取到当前要画的点的坐标
            Point point = (Point) car.next();
            // 设置点的颜色
            g.setColor(Color.RED);
            // 这个点应该是个圆形 并且画在当前点击的位置 10 表示点的大小
            g.fillOval(point.x,point.y,10,10);
        }
    }
    // 添加一个点到界面上
//    public void addPaint(Point point){
//        points.add(point);// 保存鼠标点击的点
//    }

    // 鼠标监听 - 适配器模式
    private class MyMouseListener extends MouseAdapter{
        // 鼠标点击 - 按下，弹起，按住不放
        @Override
        public void mousePressed(MouseEvent e) {
            // 获取点击对象 - 谁调用鼠标监听该对象就是谁 这类是Frame调用的
            MyFrame myFrame = (MyFrame) e.getSource();
            // 当鼠标点击时 就在对应位置画一个点
            // Point这个点就是鼠标点击的坐标的点
//            myFrame.addPaint(new Point(e.getX(),e.getY()));
            // 保存鼠标点击的点
            points.add(new Point(e.getX(),e.getY()));
            // 每次点击鼠标都重新画一次
            myFrame.repaint();
        }
    }
}


```

![image-20230608144609828](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306081448887.png)

### 窗口监听

```java
package com.etjava.gui.window;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 窗口监听事件
public class TestWindowListener {
    public static void main(String[] args) {
        new MyFrame();
    }
}

class MyFrame extends Frame{
    public MyFrame(){
        super("窗口监听事件");
        setBounds(200,200,300,300);
        setResizable(false);
        setVisible(true);
        addWindowListener(new MyWindowListener());
    }

    class MyWindowListener extends WindowAdapter{

        // 窗口关闭事件
        @Override
        public void windowClosing(WindowEvent e) {
            System.out.println("窗口关闭中");
            // 正常退出
            System.exit(0);
        }
        @Override
        public void windowOpened(WindowEvent e) {
            System.out.println("窗口打开");
        }

        @Override
        public void windowClosed(WindowEvent e) {
            System.out.println("窗口已关闭");
        }

        @Override
        public void windowIconified(WindowEvent e) {
            System.out.println("窗口打开");
        }

        @Override
        public void windowActivated(WindowEvent e) {
            System.out.println("窗口被激活");
            MyFrame frame = (MyFrame) e.getSource();
            frame.setTitle("窗口被激活了");
        }
    }
}		
```

### 键盘监听事件

```
package com.etjava.gui.keybord;

import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

// 键盘监听事件
public class TestKeyBord {
    public static void main(String[] args) {
        new KeyFrame();
    }
}

class KeyFrame extends Frame{
    public KeyFrame(){
        setBounds(200,200,300,400);
        setVisible(true);
        setBackground(Color.GREEN);
        addKeyListener(new KeyAdapter() {
            // 按下事件
            @Override
            public void keyPressed(KeyEvent e) {
                int keyCode = e.getKeyCode();
                if(keyCode==KeyEvent.VK_UP){
                    System.out.println("按下了向上箭头按键");
                }
                 // 获取键盘输入的字符
//                char c = e.getKeyChar();
//                System.out.print(c);
            }
            // 释放事件
            @Override
            public void keyReleased(KeyEvent e) {
               // System.out.println("释放按键");
            }
        });
    }
}

```

## SWING

### JFrame

#### 弹窗

```
import javax.swing.*;
import java.awt.*;

// JFrame窗口
public class TestJFrame {
    public static void main(String[] args) {
        JFrame frame = new JFrame("JFrame");
        frame.setBackground(Color.RED);// 这里需要设置容器的背景色 非窗体的
        frame.setBounds(300,300,200,200);
        frame.setVisible(true);
        // 设置窗口关闭
        /*
        DO_NOTHING_ON_CLOSE = 0 点击后什么都不做
        HIDE_ON_CLOSE = 1 隐藏窗口 程序不会退出
        DISPOSE_ON_CLOSE = 2 隐藏窗口 当jvm运行完成后才会退出
        EXIT_ON_CLOSE = 3 关闭并退出程序
         */
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        
    }
}
```

### JLabel标签居中

```java
class MyJFrame extends JFrame{
    public MyJFrame(){
        Container container = getContentPane();
        container.setBackground(Color.GREEN);
        this.setBounds(600,600,400,400);
        this.setVisible(true);
        JLabel label = new JLabel("测试JFrame窗体");
        // 标签居中
        /*
        0 水平居中
        1 TOP
        2 LEFT
        3 BOTTOM
        4 RIGHT
        5 NORTH
        6 SOUTH_WEST
        7 WEST
        ...
         */
        label.setHorizontalAlignment(SwingConstants.CENTER);// 水平居中
        add(label);
        setDefaultCloseOperation(3);// 关闭并退出
    }
}
```

![image-20230616230457101](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306162305205.png)

#### 弹窗 - 子窗口

```java
package com.etjava.gui.swing.Dialog;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// 弹窗
public class MyFrame extends JFrame{
    public MyFrame(String title){
        setBounds(300,300,400,200);
        setDefaultCloseOperation(3);
        Container container = getContentPane();
        //container.setLayout(null);
        JLabel jLabel = new JLabel("第一个JFrame窗口");
        jLabel.setHorizontalAlignment(SwingConstants.CENTER);
        container.add(jLabel);
        setVisible(true);
        JButton button = new JButton("弹出对话框");
        button.setBounds(0,0,100,30);
        button.setVisible(true);
        add(button);
        button.addActionListener(new ActionListener() {     //添加按钮鼠标点击事件
            public void actionPerformed(ActionEvent e) {
                new MyJDialog(MyFrame.this).setVisible(true);
            }
        });
    }
    public static void main(String[] args) {
        new MyFrame("测试弹窗");
    }
}

// 子窗口
class MyJDialog extends JDialog {
    public MyJDialog(MyFrame frame){
        super(frame,"这是第一个JDialog窗口",true);
        Container container = getContentPane();
        setBounds(450,450,400,400);
        JLabel jLabel = new JLabel("这是一个JDialog窗口");
        container.add(jLabel);
    }
}

```

![image-20230616235513310](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306162355896.png)

### 标签

#### 创建标签

```java
new JLabel("用户名：");
```

#### 图标

Label中可以添加图标 图标可以是自定义的图片 也可以是基础形状等

```java
package com.etjava.gui.swing.label;

import javax.swing.*;
import java.awt.*;

// 标签
// 要使用图标 必须实现Icon接口
public class TestJLabel extends  JFrame implements Icon{
    private int w;// 图标的宽
    private int h;// 图标的高
    public TestJLabel(){}
    public TestJLabel(int w,int h){
        this.w = w;
        this.h = h;
    }
    public static void main(String[] args) {
        new TestJLabel().init();
    }

    public void init(){
        TestJLabel icon = new TestJLabel(15, 15);
        // 图标可以放在标签上，也可以放在按钮上等
        // 参数1 标签显示的文本，参数2 图标，参数3 标签中图标的位置
        JLabel label = new JLabel("userName:", icon, SwingConstants.CENTER);
        Container container = getContentPane();
        container.add(label);// 添加到容器中

        setVisible(true);
        setBounds(300,300,400,400);
        setDefaultCloseOperation(3);

    }

    // 画图标
    /*
    Component c,  图标存放的位置
    Graphics g,   画笔
    int x,      图标的坐标
    int y

     */
    @Override
    public void paintIcon(Component c, Graphics g, int x, int y) {
        // 画一个圆  w h 图标的宽度和高度
        g.drawOval(x,y,w,h);
    }

    // 获取图标的宽度
    @Override
    public int getIconWidth() {
        return this.w;
    }
    // 获取图标的高度
    @Override
    public int getIconHeight() {
        return this.h;
    }
}

```

![image-20230617150103234](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306171501415.png)

图标使用图片替代

```java
import javax.swing.*;
import java.awt.*;
import java.net.URL;

// 标签中使用图片
public class TesIcon extends  JFrame{

    public TesIcon(){
        // 读取图片
        URL url = TesIcon.class.getResource("1.jpeg");
        // 把图片放到ImageIcon组件中
        ImageIcon imageIcon = new ImageIcon(url);
        // 图标可以放在标签上，也可以放在按钮上等
        // 参数1 标签显示的文本，参数2 图标，参数3 标签中图标的位置
        JLabel label = new JLabel("userName:");
        // 添加图片到label
        label.setIcon(imageIcon);
        // 居中显示
        label.setHorizontalAlignment(SwingConstants.CENTER);

        // 窗体中的所有组件必须放到容器中才能显示
        Container container = getContentPane();
        container.add(label);// 添加到容器中

        setVisible(true);
        setBounds(300,300,400,400);
        setDefaultCloseOperation(3);
    }
    public static void main(String[] args) {
        new TesIcon();
    }

}

```

![image-20230617151846719](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306171518134.png)

### 面板

面板布局

```java
package com.etjava.gui.swing.jpanel;

import javax.swing.*;
import java.awt.*;

// 面板
public class TestJpanel extends JFrame {
    public TestJpanel(){
        Container container = getContentPane();
        // 后边的两个10 多个面板之间的间距
        container.setLayout(new GridLayout(2,1,10,10));
        // 创建面板
        JPanel panel1 = new JPanel(new GridLayout(1,3));
        JPanel panel2 = new JPanel(new GridLayout(1,2));
        JPanel panel3 = new JPanel(new GridLayout(2,1));
        JPanel panel4 = new JPanel(new GridLayout(3,2));
        panel1.add(new JButton("panel - 1"));
        panel1.add(new JButton("panel - 1"));
        panel1.add(new JButton("panel - 1"));
        panel2.add(new JButton("panel - 2"));
        panel2.add(new JButton("panel - 2"));
        panel3.add(new JButton("panel - 3"));
        panel3.add(new JButton("panel - 3"));
        panel4.add(new JButton("panel - 4"));
        panel4.add(new JButton("panel - 4"));
        panel4.add(new JButton("panel - 4"));
        panel4.add(new JButton("panel - 4"));
        panel4.add(new JButton("panel - 4"));
        panel4.add(new JButton("panel - 4"));

        // 添加到面板
        container.add(panel1);
        container.add(panel2);
        container.add(panel3);
        container.add(panel4);
        // 弹窗显示
        setVisible(true);
        setBounds(300,300,600,400);
        setDefaultCloseOperation(3);
    }

    public static void main(String[] args) {
        new TestJpanel();
    }
}

```

![image-20230617153209932](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306171532151.png)

#### JScrollPanel

面板滚动条

```java
package com.etjava.gui.swing.jpanel;

import javax.swing.*;
import java.awt.*;

// 测试滚动条
public class TestJScrollPanel extends JFrame {

    public TestJScrollPanel(){
        Container container = getContentPane();
        // 文本域
        JTextArea textArea = new JTextArea(20, 50);
        // 可设置默认文字
        textArea.setText("hello world");
        // 将文本域放到面板中 - 不能直接放到容器 
        JScrollPane scrollPane = new JScrollPane(textArea);
        container.add(scrollPane);


        setBounds(300,300,500,150);
        setVisible(true);
        setDefaultCloseOperation(3);

    }

    public static void main(String[] args) {
        new TestJScrollPanel();
    }
}

```

![image-20230617153922741](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306171539604.png)

### JLabel扩展

标签中图片大小设置

ImageIcon转为Image进行设置大小 ，使用时在转回去

imageIcon.getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT);

转回去 new ImageIcon(image);

```java
import javax.swing.*;
import java.awt.*;
import java.net.URL;

// 标签中使用图片
public class TestIcon extends  JFrame{

    public TestIcon(){
        // 读取图片
        URL url = TestIcon.class.getResource("1.jpeg");
        // 把图片放到ImageIcon组件中
        ImageIcon imageIcon = new ImageIcon(url);

        // 设置图片大小
        int width = imageIcon.getIconWidth();
        int height = imageIcon.getIconHeight();
        System.out.println("原图片大小："+width+" * "+height);

        // 修改图片大小为100
        Image image = imageIcon.getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT);
        ImageIcon newImage = new ImageIcon(image);
        int iconHeight = newImage.getIconHeight();
        int iconWidth = newImage.getIconWidth();
        System.out.println("修改后图片大小："+iconWidth+" * "+iconHeight);


        // 图标可以放在标签上，也可以放在按钮上等
        // 参数1 标签显示的文本，参数2 图标，参数3 标签中图标的位置
        JLabel label = new JLabel("userName:");
        // 添加图片到label
        label.setIcon(newImage);
        // 居中显示
        label.setHorizontalAlignment(SwingConstants.CENTER);

        // 窗体中的所有组件必须放到容器中才能显示
        Container container = getContentPane();
        container.add(label);// 添加到容器中

        setVisible(true);
        setBounds(300,300,400,400);
        setDefaultCloseOperation(3);
    }
    public static void main(String[] args) {
        new TestIcon();
    }

}

```

![image-20230620152138622](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306201521900.png)

### 按钮

#### 图片按钮

```java
import javax.swing.*;
import java.awt.*;
import java.net.URL;

// 测试按钮
public class TestButton1 extends JFrame {

    public TestButton1() {
        // 获取容器 使用JFrame需要通过容器进行绑定各种组件
        Container container = getContentPane();
        // 将一个图片定义为图标
        URL url = TestButton1.class.getResource("1.jpeg");
        ImageIcon icon = new ImageIcon(url);
        // 改变图片大小
        Image image = icon.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon icon1 = new ImageIcon(image);
        // 把图标放到按钮上
        JButton button = new JButton();
        button.setIcon(icon1);
        // 设置提示信息
        button.setToolTipText("图片按钮");
        // 将按钮添加到容器
        container.add(button,BorderLayout.NORTH);

        // 设置窗体属性
        setVisible(true);
        setBounds(300,300,200,200);
        setDefaultCloseOperation(3);

    }

    public static void main(String[] args) {
        new TestButton1();
    }
}

```

![image-20230620153748621](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306201537080.png)

#### 单选按钮

使用单选按钮时需要注意：创建出来的单选按钮必须要放到同一个组中 - ButtonGroup

```java
package com.etjava.gui.swing.jbutton;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

// 测试按钮
public class TestButton2 extends JFrame {

    public TestButton2() {
        // 获取容器 使用JFrame需要通过容器进行绑定各种组件
        Container container = getContentPane();
        // 单选按钮 JRadioButton
        JRadioButton button1 = new JRadioButton("RadioButton-1");
        JRadioButton button2 = new JRadioButton("RadioButton-2");
        JRadioButton button3 = new JRadioButton("RadioButton-3");

        // 单选框只能选择一个 需要放到一个组中
        ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(button1);
        buttonGroup.add(button2);
        buttonGroup.add(button3);

        JPanel panel = new JPanel(new GridLayout(1,3));
        panel.add(button1);
        panel.add(button2);
        panel.add(button3);
        // 将按钮添加到容器
        container.add(panel);

        // 设置窗体属性
        setVisible(true);
        setBounds(200,300,500,500);
        setDefaultCloseOperation(3);

    }

    public static void main(String[] args) {
        new TestButton2();
    }
}

```

![image-20230620154802345](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306201548580.png)

#### 多选按钮

多选框使用JCheckBox

```java
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// 测试按钮
public class TestButton3 extends JFrame {

    public TestButton3() {
        // 获取容器 使用JFrame需要通过容器进行绑定各种组件
        Container container = getContentPane();

        // 多选框只能选择一个
        JCheckBox jCheckBox1 = new JCheckBox("check - 1");
        JCheckBox jCheckBox2 = new JCheckBox("check - 2");
        JCheckBox jCheckBox3 = new JCheckBox("check - 3");

        // 单选框绑定事件
        jCheckBox1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JCheckBox ck = (JCheckBox)e.getSource();
                System.out.println("选中了 - "+ ck.getText());
            }
        });
        jCheckBox2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JCheckBox ck = (JCheckBox)e.getSource();
                System.out.println("选中了 - "+ ck.getText());
            }
        });
        jCheckBox3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JCheckBox ck = (JCheckBox)e.getSource();
                System.out.println("选中了 - "+ ck.getText());
            }
        });

        JPanel panel = new JPanel(new GridLayout(1,3));
        panel.add(jCheckBox1);
        panel.add(jCheckBox2);
        panel.add(jCheckBox3);
        // 将按钮添加到容器
        container.add(panel);
        // 设置窗体属性
        setVisible(true);
        setBounds(200,300,500,500);
        setDefaultCloseOperation(3);

    }

    public static void main(String[] args) {
        new TestButton3();
    }
}

```

![image-20230620155518915](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306201555217.png)

### 下拉框



```java
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// 测试按钮
public class TestCombobox extends JFrame {

    public TestCombobox() {
        // 获取容器 使用JFrame需要通过容器进行绑定各种组件
        Container container = getContentPane();

        // 下拉框
        JComboBox states = new JComboBox();
        states.addItem("=====请选择=====");
        states.addItem("盗墓笔记");
        states.addItem("鬼吹灯");
        states.addItem("夜探珍妃墓");

        // 获取选中的值
        states.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JComboBox source = (JComboBox) e.getSource();
                System.out.println(source.getSelectedItem());
            }
        });

        JPanel panel = new JPanel(new GridLayout(1,1));
        panel.add(states);
        // 将按钮添加到容器
        container.add(panel,BorderLayout.NORTH);
        // 设置窗体属性
        setVisible(true);
        setBounds(200,300,500,500);
        setDefaultCloseOperation(3);

    }

    public static void main(String[] args) {
        new TestCombobox();
    }
}

```

![image-20230620160329737](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306201603853.png)

### 列表框

```java
package com.etjava.gui.swing.jbutton;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// 测试按钮
public class TestJList extends JFrame {

    public TestJList() {
        // 获取容器 使用JFrame需要通过容器进行绑定各种组件
        Container container = getContentPane();

        // 列表框
       // 生成列表需要展示的数据
        String[] data = {"Tom","Jerry","Lily","Andy"};
        // 定义列表框
        JList list = new JList(data);

        JPanel panel = new JPanel(new GridLayout(1,1));
        panel.add(list);
        // 将按钮添加到容器
        container.add(panel,BorderLayout.NORTH);
        // 设置窗体属性
        setVisible(true);
        setBounds(200,300,500,500);
        setDefaultCloseOperation(3);

    }

    public static void main(String[] args) {
        new TestJList();
    }
}

```



![image-20230620160832751](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306201608668.png)

扩展 - 动态添加列表中的数据

```java
// 生成列表需要展示的数据
Vector data = new Vector();
// 定义列表框
JList list = new JList(data);
// 动态添加数据
data.add("Tom");
data.add("Jerry");
JPanel panel = new JPanel(new GridLayout(1,1));
panel.add(list);
// 将按钮添加到容器
container.add(panel,BorderLayout.NORTH);
```

### 文本框

#### 普通文本框

```java
import javax.swing.*;
import java.awt.*;
import java.util.Vector;

// 文本框 - 普通文本框
public class TestText01 extends JFrame {

    public TestText01() {
        // 获取容器 使用JFrame需要通过容器进行绑定各种组件
        Container container = getContentPane();

        // 文本框
        JTextField text = new JTextField("默认显示的文字");
        text.setToolTipText("这是一个文本框");

        JPanel panel = new JPanel(new GridLayout(1,1));
        panel.add(text);
        // 将按钮添加到容器
        container.add(panel,BorderLayout.NORTH);
        // 设置窗体属性
        setVisible(true);
        setBounds(200,300,500,500);
        setDefaultCloseOperation(3);

    }

    public static void main(String[] args) {
        new TestText01();
    }
}

```

![image-20230620161659851](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306201617285.png)

#### 密码框

密码框除了我们手动设置echoChar('*') 方式外 还可以直接使用JPasswordField()

```java
import javax.swing.*;
import java.awt.*;

// 文本框 - 密码框
public class TestPasswordField extends JFrame {

    public TestPasswordField() {
        // 获取容器 使用JFrame需要通过容器进行绑定各种组件
        Container container = getContentPane();

        // 密码框
        JPasswordField passwordField = new JPasswordField();
        passwordField.setEchoChar('*');// 将输入的文本以*代替显示


        JPanel panel = new JPanel(new GridLayout(1,1));
        panel.add(passwordField);
        // 将按钮添加到容器
        container.add(panel,BorderLayout.NORTH);
        // 设置窗体属性
        setVisible(true);
        setBounds(200,300,500,500);
        setDefaultCloseOperation(3);

    }

    public static void main(String[] args) {
        new TestPasswordField();
    }
}

```

![image-20230620162226054](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306201622214.png)

#### 文本域

JPanel 不会出现滚动条，JScrollPane会出现滚动条

```java
import javax.swing.*;
import java.awt.*;

// 文本框 - 文本域
public class TestJTextArea extends JFrame {

    public TestJTextArea() {
        // 获取容器 使用JFrame需要通过容器进行绑定各种组件
        Container container = getContentPane();

        // 文本域
        JTextArea area = new JTextArea(20,50);
        // 面板 - 超出出现滚动条
        // 注意 JPanel 不会出现滚动条
        JScrollPane pane = new JScrollPane(area);


        JPanel panel = new JPanel(new GridLayout(1,1));
        panel.add(pane);
        // 将按钮添加到容器
        container.add(panel,BorderLayout.NORTH);
        // 设置窗体属性
        setVisible(true);
        setBounds(200,300,500,500);
        setDefaultCloseOperation(3);

    }

    public static void main(String[] args) {
        new TestJTextArea();
    }
}

```



![image-20230620162541496](https://cdn.jsdelivr.net/gh/etjava/TyporaPIC/img/202306201625708.png)

## 综合案例1

### 贪吃蛇

```
帧的概念：
	如果时间片足够小 就是动画，例如 每秒30帧 连起来就是动画，拆开就是静态图片
还需要键盘监听事件 控制小蛇的移动于暂停
定时器 Timer


设计思路：
一个主类 作为启动类，一个数据来源的类 存放游戏中用到的数据(图片)
一个游戏主类（游戏中所有的组件都放到面板中）
数据来源类：
	定义游戏中的数据来源 小蛇的头部 身体 食物等
启动类：
	把游戏主类添加进来即可
游戏主类：
	先定义小蛇的一些属性
	小蛇的长度（用来做积分）
	小蛇的坐标 （用来控制小蛇移动方向）
	小蛇的初始化方向
	食物的坐标（食物坐标应为随机的）
	默认停止游戏属性
	默认非失败游戏的属性
	记录分数
	定时器(用来刷新频率的 刷新的频率越高 小蛇的移动速度就越快)
	获取焦点事件
	键盘事件
	绘制小蛇到面板中
	

类
SnakeGame 游戏主启动类
SnakePanel 游戏的面板 所有的东西都要放到面板中
Data 游戏的数据来源，所有的数据包括图片都封装在该类中

```

#### 源码

##### 启动类

```java
package com.etjava.gui.swing.snake;

import javax.swing.*;

// 启动类 - 用来启动游戏的
public class SnakeGame {
    public static void main(String[] args) {

        System.out.println(SnakeGame.class.getResource(""));

        // 创建窗体
        JFrame frame = new JFrame("贪吃蛇");
        // 添加面板
        frame.add(new SnakePanel());
        // 设置窗口可见
        frame.setVisible(true);
        // 设置窗口的位置
        frame.setBounds(600,200,900,720);
        // 窗口固定大小
        frame.setResizable(false);
        // 窗口可关闭
        frame.setDefaultCloseOperation(3);

    }
}

```

##### 数据来源类

```java
package com.etjava.gui.swing.snake;

import javax.swing.*;
import java.net.URL;

// 存放游戏中需要的所有数据
public class Data {

    // 图片相关数据
    private static URL headerURL = Data.class.getResource("/static/header.png");// 绝对路径
    private static URL upURL = Data.class.getResource("/static/up.png");
    private static URL downURL = Data.class.getResource("/static/down.png");
    private static URL leftURL = Data.class.getResource("/static/left.png");
    private static URL rightURL = Data.class.getResource("/static/right.png");

    private static URL bodyURL = Data.class.getResource("/static/body.png");
    private static URL foodURL = Data.class.getResource("/static/food.png");
    public static ImageIcon header = new ImageIcon(headerURL);
    public static ImageIcon up = new ImageIcon(upURL);
    public static ImageIcon down = new ImageIcon(downURL);
    public static ImageIcon left = new ImageIcon(leftURL);
    public static ImageIcon right = new ImageIcon(rightURL);
    public static ImageIcon body = new ImageIcon(bodyURL);
    public static ImageIcon food = new ImageIcon(foodURL);

}

```

##### 游戏主类

```java
package com.etjava.gui.swing.snake;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

// 游戏的面板
public class SnakePanel extends JPanel implements KeyListener, ActionListener {


    // 小蛇的数据结构
    int length;// 小蛇的长度
    /*
        面板总大小 850 * 600
        计算蛇最大可以有多长
        这里的850和600 是面板的大小   25是蛇的身体(像素)大小
        (850*25)*(600*25) = 816
     */
    int[] snakeX = new int[600];// 蛇的X坐标
    int[] snakeY = new int[500];// 蛇的Y坐标
    String fx;// 初始化时 小蛇的方向

    // 游戏当前的状态 - 开始  停止
    boolean isStart = false;// 默认是停止的

    // 食物的坐标
    int foodX;
    int foodY;
    Random random = new Random();// 食物的位置
    // 定时器
    Timer timer = new Timer(100,this);// 一百毫秒执行一次
    // 游戏状态 默认false 非失败的
    boolean isFail;

    // 游戏得分
    int score;

    public SnakePanel(){
        init();// 初始化小蛇
        this.setFocusable(true);// 获取焦点事件
        this.addKeyListener(this);// 获取键盘事件 因为直接实现类KeyListener接口 这里传当前类对象即可
        timer.start();// 游戏一开始就启动定时器
    }


    // 初始化小蛇
    public void init(){
        length=3;// 小蛇初始化为3节
        snakeX[0] = 100;snakeY[0] = 100;// 头的坐标
        snakeX[1] = 75;snakeY[1] = 100;// 第一节身体的坐标
        snakeX[2] = 50;snakeY[2] = 100;// 第二节身体的坐标
        fx = "right";// 初始化时 小蛇的方向
        // 初始化食物 随机分布
        foodX = 25+25*random.nextInt(34);// 这里的34是panel中最大可存放的小蛇身体数量 X
        foodY = 75+25*random.nextInt(24);// 这里的24是panel中最大可存放的小蛇身体数量 Y
    }

    // 定时器 - 让小蛇的身体动起来
    // 需要添加一个监听事件 在监听事件中来刷新面板 例如 每秒刷新10次
    @Override
    public void actionPerformed(ActionEvent e) {
        if(isStart && isFail == false){

            if(length>50){// 小蛇提速
                timer = new Timer(50,this);
            }

            // 吃食物
            if(snakeX[0] == foodX && snakeY[0] == foodY){// 小蛇的头部与身体 和 食物的坐标重合了 表示吃掉一个食物
                length++;// 小蛇长度+1
                score++; // 得分+1
                // 重新随机分配食物
                foodX = 25+25*random.nextInt(34);// 这里的34是panel中最大可存放的小蛇身体数量 X
                foodY = 75+25*random.nextInt(24);// 这里的24是panel中最大可存放的小蛇身体数量 Y
            }

            if(isStart){// 如果状态为开始状态 就让小蛇动起来
                // 默认右移
                for (int i = length-1; i > 0; i--) {// 头部和身体都向前移动一节
                    snakeX[i] = snakeX[i-1];
                    snakeY[i] = snakeY[i-1];
                }
                // 小蛇的走向
                if(fx.equals("right")){
                    snakeX[0] = snakeX[0]+25;
                    // 判断屏幕边界 如果超出屏幕需要回到最初位置
                    if(snakeX[0]>850){
                        snakeX[0]=25;
                    }
                }else if(fx.equals("left")){
                    snakeX[0] = snakeX[0]-25;
                    // 判断屏幕边界 如果超出屏幕需要回到最初位置
                    if(snakeX[0]<25){
                        snakeX[0]=850;
                    }
                }else if(fx.equals("up")){
                    snakeY[0] = snakeY[0]-25;
                    // 判断屏幕边界 如果超出屏幕需要回到最初位置
                    if(snakeY[0]<75){
                        snakeY[0]=650;
                    }
                }else if(fx.equals("down")){
                    snakeY[0] = snakeY[0]+25;
                    // 判断屏幕边界 如果超出屏幕需要回到最初位置
                    if(snakeY[0]>650){
                        snakeY[0]=75;
                    }
                }
                // 如果撞到自己就算失败
                for (int i = 1; i < length; i++) {
                    // 头和身体重合则表示失败
                    if (snakeX[0] == snakeX[i] && snakeY[0] == snakeY[i]) {
                        isFail = true;
                    }
                }
                // 撞到边界也算失败
                if(snakeX[0]==850 || snakeY[0]==650){
                    isFail = true;
                }
                // 开启定时器
                timer.start();
            }
            repaint();
        }
    }


    // 绘制面板，这个游戏中的所有东西 都是以该画笔来画
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);// 清屏  不使用会出现闪烁
        // 面板颜色
        this.setBackground(Color.WHITE);
        //绘制静态面板
        // 头部的广告栏
        // this表示在当前面板绘制，g表示画笔 后面两个参数为图片的位置
        Data.header.paintIcon(this,g,25,11);
        // 画一个长方形 注意需要与广告栏对齐
        g.fillRect(25,75,850,600);
        // 添加积分
        g.setColor(Color.BLUE);
        g.setFont(new Font("汉仪瘦金体繁",Font.BOLD,30));
        g.drawString("长度 "+length,750,35);
        g.drawString("得分 "+score,750,55);

        // 把小蛇画到面板中
        // 判断蛇头的方向
        if(fx.equals("right")){
            Data.right.paintIcon(this,g,snakeX[0],snakeY[0]);// 蛇的头部初始化向右
        }else if(fx.equals("left")){
            Data.left.paintIcon(this,g,snakeX[0],snakeY[0]);// 蛇的头部初始化向右
        }else if(fx.equals("up")){
            Data.up.paintIcon(this,g,snakeX[0],snakeY[0]);// 蛇的头部初始化向右
        }else if(fx.equals("down")){
            Data.down.paintIcon(this,g,snakeX[0],snakeY[0]);// 蛇的头部初始化向右
        }
        // 添加食物
        Data.food.paintIcon(this,g,foodX,foodY);

        // 动态添加小蛇的身体
        for (int i = 1; i < length; i++) {
            Data.body.paintIcon(this,g,snakeX[i],snakeY[i]);// 小蛇的身体
        }

        // 游戏状态 - 如果是停止状态 需要给出提示信息
        if(!isStart){
            // 设置画笔颜色
            g.setColor(Color.WHITE);
            // 设置字体 微软雅黑
            g.setFont(new Font("汉仪瘦金体繁",Font.BOLD,50));
            // 添加文字
            g.drawString("按下空格开始游戏",260,330);
        }

        // 判断游戏是否失败
        if(isFail){
            g.setColor(Color.RED);
            g.setFont(new Font("汉仪瘦金体繁",Font.BOLD,50));
            g.drawString("失败！ 按下空格重新开始",140,330);
        }

    }


    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    // 键盘按下后的监听事件
    @Override
    public void keyPressed(KeyEvent e) {
        // 获取键盘按键
        int keyCode = e.getKeyCode();
        if(keyCode==KeyEvent.VK_SPACE){// 空格
            if(isFail){
                // 重新开始游戏
                isFail = false;
                init();
            }else{
                // 第一次按开始 第二次按停止 因此这里需要取反 不能直接写true
                isStart = !isStart;
            }
            repaint();// 重新绘制面板
        }
        // 小蛇多方向移动
        if(keyCode == KeyEvent.VK_UP){// 向上移动
            fx = "up";
        }else if(keyCode == KeyEvent.VK_DOWN){// 向下移动
            fx = "down";
        }else if(keyCode == KeyEvent.VK_LEFT){// 向左移动
            fx = "left";
        }else if(keyCode == KeyEvent.VK_RIGHT){// 向右移动
            fx = "right";
        }
    }


}

```

![image-20230623093214356](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230623093214356.png)



![image-20230623093339494](C:\Users\etjav\AppData\Roaming\Typora\typora-user-images\image-20230623093339494.png)

































































































































































































