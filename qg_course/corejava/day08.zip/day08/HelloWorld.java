public class HelloWorld{
	// args -> 26
	public static void main(String[] abcdefghijklmnopqrstuvwxyz){
		System.out.println("HelloWorld");
	}


}