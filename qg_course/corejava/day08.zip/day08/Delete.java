import java.io.*;
public class Delete{
	public static void main(String[] args){
		File target = new File(".");
		File[] files = target.listFiles(new FilenameFilter(){
			@Override
			public boolean accept(File dir,String name){
				return name.toLowerCase().endsWith(".class");
			}
		});

		for(File f:files)
			f.delete();
	}
}