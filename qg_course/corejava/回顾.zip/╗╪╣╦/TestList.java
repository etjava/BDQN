import java.util.*;
import java.io.*;
public class TestList{
	public static void main(String[] args){
		/*
		int[] data = {1,2,3,4};
		//int[] data2 = new int[10];

		List<Integer> list = new ArrayList<>();
		list.add(1);
		list.add(2);

		int a = 100;
		Integer num = a;
		byte[] bytes = num.toString().getBytes();
		for(int i=0;i<bytes.length;i++){
			System.out.println(bytes[i]);
		}
		*/

		/*
		System.out.println(10%4);
		System.out.println(10&3);
		*/
		/*
		System.out.println(1<<2);
		System.out.println((1<<31)-1);

		System.out.println(!true);

		System.out.println(~10);

		int month = 12;
		switch(month){
			case 1: System.out.println("һ��"); break;
			case 2: System.out.println("����"); break;
			case 3: System.out.println("����"); break;
			default: System.out.println("������Ч");
		}
		*/

		// new Cat("helloKitty");
		InputStream is = null;
		try{
			is = new FileInputStream("hello.txt");
			System.out.println(is.read());
			// ...

		}catch(IOException e){
			e.printStackTrace();
		}finally{
			if(is!=null)
				try{
					is.close();
				}catch(IOException e){
					e.printStackTrace();
				}
		}
	}
}
/*
class Animal{
	//a=10;
	public Animal(int num){}

	void test(){}

	static{
		// ��̬�����
	}
}

class Cat extends Animal{
	public Cat(){
		System.out.println("2");
	}
	public Cat(String name){
		// super();
		this();
		System.out.println("3");
	}

}
*/