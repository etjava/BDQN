import java.util.*;
import javax.swing.*;
import java.text.*;
public class HelloWorld{
	public static void main(String[] args){
		SimpleDateFormat sdf = new SimpleDateFormat("YYYY-mm-DD HH:mm:ss");
		String date = sdf.format(new Date());
        JOptionPane.showMessageDialog(null,"��ǰʱ�䣺"+date);
	}
}